import Link from "next/link"
import { ArrowRight, BarChart3, Car, Cpu, Leaf, MapPin, Battery, Zap, Globe, TrendingUp } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
          <div className="flex gap-6 md:gap-10">
            <Link href="/" className="flex items-center space-x-2">
              <Leaf className="h-6 w-6 text-primary" />
              <span className="inline-block font-bold">Green Corridor System</span>
            </Link>
            <nav className="hidden gap-6 md:flex">
              <Link
                href="/dashboard"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary nav-link"
              >
                Dashboard
              </Link>
              <Link
                href="/traffic-map"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary nav-link"
              >
                Traffic Map
              </Link>
              <Link
                href="/analytics"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary nav-link"
              >
                Analytics
              </Link>
              <Link
                href="/settings"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary nav-link"
              >
                Settings
              </Link>
            </nav>
          </div>
          <div className="flex flex-1 items-center justify-end space-x-4">
            <Button variant="outline" asChild className="border-primary/20 hover:bg-primary/10 transition-all">
              <Link href="/login">Login</Link>
            </Button>
            <Button asChild className="bg-gradient-primary hover:opacity-90 transition-all">
              <Link href="/dashboard">Go to Dashboard</Link>
            </Button>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48 hero-section bg-gradient-green-white">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 xl:grid-cols-2">
              <div className="flex flex-col justify-center space-y-4 hero-content animate-fade-in">
                <div className="space-y-2">
                  <Badge className="badge-green mb-2 animate-bounce-in" style={{ animationDelay: "0.2s" }}>
                    Eco-Friendly Traffic Management
                  </Badge>
                  <h1
                    className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none bg-clip-text text-transparent bg-gradient-primary animate-fade-in"
                    style={{ animationDelay: "0.3s" }}
                  >
                    AI-Powered Green Corridor System
                  </h1>
                  <p
                    className="max-w-[600px] text-muted-foreground md:text-xl animate-fade-in"
                    style={{ animationDelay: "0.4s" }}
                  >
                    Revolutionizing urban traffic management with intelligent, adaptive traffic signals that prioritize
                    electric and autonomous vehicles for a greener future.
                  </p>
                </div>
                <div
                  className="flex flex-col gap-2 min-[400px]:flex-row animate-fade-in"
                  style={{ animationDelay: "0.5s" }}
                >
                  <Button
                    asChild
                    size="lg"
                    className="bg-gradient-primary hover:opacity-90 transition-all btn-hover-effect"
                  >
                    <Link href="/dashboard">
                      Explore Dashboard <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                  <Button
                    variant="outline"
                    size="lg"
                    asChild
                    className="border-primary/20 hover:bg-primary/10 transition-all"
                  >
                    <Link href="/traffic-map">View Traffic Map</Link>
                  </Button>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <img
                  src="https://sjc.microlink.io/sLWj9GyaEr0qsw9fEGniseuMLybpBCoZLlXWeUdU37yYWOK3lu99PRpAODe4M2-5Mo6wZKBit1dHlVgjzlVDmg.jpeg"
                  alt="Smart Traffic Intersection with Intelligent Traffic Management System"
                  className="rounded-lg object-cover shadow-xl border-4 border-white animate-float"
                  width={550}
                  height={550}
                />
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-green-subtle">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2 animate-fade-in">
                <Badge className="badge-green mb-2">Smart City Solutions</Badge>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl bg-clip-text text-transparent bg-gradient-primary">
                  Key Features
                </h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Our system combines AI, IoT, and traffic engineering to create smarter, more efficient urban
                  transportation networks.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-2 lg:grid-cols-3">
              <Card className="feature-card animate-scale-in" style={{ animationDelay: "0.1s" }}>
                <CardHeader>
                  <div className="feature-card-icon">
                    <Cpu className="h-6 w-6" />
                  </div>
                  <CardTitle>Intelligent Traffic Management</CardTitle>
                  <CardDescription>
                    Real-time analysis and adaptive signal timing based on current traffic conditions.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p>
                    Processes data from IoT sensors to monitor traffic and automatically adjusts signals to optimize
                    flow.
                  </p>
                </CardContent>
                <CardFooter>
                  <Button variant="ghost" asChild className="w-full group text-primary hover:text-primary/90">
                    <Link href="/dashboard" className="flex items-center justify-center">
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
              <Card className="feature-card animate-scale-in" style={{ animationDelay: "0.2s" }}>
                <CardHeader>
                  <div className="feature-card-icon">
                    <Car className="h-6 w-6" />
                  </div>
                  <CardTitle>Vehicle-Specific Optimization</CardTitle>
                  <CardDescription>
                    Prioritizes electric and autonomous vehicles to improve energy efficiency.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p>
                    Reduces unnecessary stops for EVs to conserve battery power and creates smooth traffic patterns for
                    AVs.
                  </p>
                </CardContent>
                <CardFooter>
                  <Button variant="ghost" asChild className="w-full group text-primary hover:text-primary/90">
                    <Link href="/analytics" className="flex items-center justify-center">
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
              <Card className="feature-card animate-scale-in" style={{ animationDelay: "0.3s" }}>
                <CardHeader>
                  <div className="feature-card-icon">
                    <BarChart3 className="h-6 w-6" />
                  </div>
                  <CardTitle>Comprehensive Dashboard</CardTitle>
                  <CardDescription>
                    Visualizes traffic conditions and performance metrics across all corridors.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p>Tracks efficiency metrics, vehicle distribution, and energy savings in real-time.</p>
                </CardContent>
                <CardFooter>
                  <Button variant="ghost" asChild className="w-full group text-primary hover:text-primary/90">
                    <Link href="/dashboard" className="flex items-center justify-center">
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
              <Card className="feature-card animate-scale-in" style={{ animationDelay: "0.4s" }}>
                <CardHeader>
                  <div className="feature-card-icon">
                    <MapPin className="h-6 w-6" />
                  </div>
                  <CardTitle>Interactive Traffic Map</CardTitle>
                  <CardDescription>Visualize traffic flow and corridor status in real-time.</CardDescription>
                </CardHeader>
                <CardContent>
                  <p>Interactive map showing traffic density, signal status, and vehicle distribution.</p>
                </CardContent>
                <CardFooter>
                  <Button variant="ghost" asChild className="w-full group text-primary hover:text-primary/90">
                    <Link href="/traffic-map" className="flex items-center justify-center">
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
              <Card className="feature-card animate-scale-in" style={{ animationDelay: "0.5s" }}>
                <CardHeader>
                  <div className="feature-card-icon">
                    <Leaf className="h-6 w-6" />
                  </div>
                  <CardTitle>Environmental Benefits</CardTitle>
                  <CardDescription>Reduces emissions and extends EV battery range.</CardDescription>
                </CardHeader>
                <CardContent>
                  <p>Decreases vehicle emissions by minimizing idling and stop-and-go traffic patterns.</p>
                </CardContent>
                <CardFooter>
                  <Button variant="ghost" asChild className="w-full group text-primary hover:text-primary/90">
                    <Link href="/analytics" className="flex items-center justify-center">
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
              <Card className="feature-card animate-scale-in" style={{ animationDelay: "0.6s" }}>
                <CardHeader>
                  <div className="feature-card-icon">
                    <Battery className="h-6 w-6" />
                  </div>
                  <CardTitle>EV Charging Network</CardTitle>
                  <CardDescription>Integrated charging station finder and route planning.</CardDescription>
                </CardHeader>
                <CardContent>
                  <p>
                    Locate available charging stations and plan routes with optimal charging stops for electric
                    vehicles.
                  </p>
                </CardContent>
                <CardFooter>
                  <Button variant="ghost" asChild className="w-full group text-primary hover:text-primary/90">
                    <Link href="/traffic-map" className="flex items-center justify-center">
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-primary text-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2 animate-fade-in">
                <Badge className="bg-white/20 text-white border-white/30">Environmental Impact</Badge>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-white">
                  Making Cities Greener
                </h2>
                <p className="max-w-[900px] text-white/80 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Our system creates significant environmental and economic benefits for cities.
                </p>
              </div>
              <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 py-8 md:grid-cols-2 lg:grid-cols-4">
                <div
                  className="flex flex-col items-center space-y-2 glass-effect rounded-lg p-6 animate-scale-in"
                  style={{ animationDelay: "0.1s" }}
                >
                  <div className="text-4xl font-bold">15%</div>
                  <p className="text-sm text-center">Extended EV Battery Range</p>
                </div>
                <div
                  className="flex flex-col items-center space-y-2 glass-effect rounded-lg p-6 animate-scale-in"
                  style={{ animationDelay: "0.2s" }}
                >
                  <div className="text-4xl font-bold">25%</div>
                  <p className="text-sm text-center">Reduced Traffic Congestion</p>
                </div>
                <div
                  className="flex flex-col items-center space-y-2 glass-effect rounded-lg p-6 animate-scale-in"
                  style={{ animationDelay: "0.3s" }}
                >
                  <div className="text-4xl font-bold">20%</div>
                  <p className="text-sm text-center">Decreased Vehicle Emissions</p>
                </div>
                <div
                  className="flex flex-col items-center space-y-2 glass-effect rounded-lg p-6 animate-scale-in"
                  style={{ animationDelay: "0.4s" }}
                >
                  <div className="text-4xl font-bold">30%</div>
                  <p className="text-sm text-center">Improved Traffic Flow</p>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32 bg-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <div className="space-y-2 animate-fade-in">
                <Badge className="badge-green mb-2">Sustainable Transportation</Badge>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl bg-clip-text text-transparent bg-gradient-primary">
                  Why Choose Green Corridor?
                </h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Our innovative approach to traffic management delivers real benefits for cities, citizens, and the
                  environment.
                </p>
              </div>
            </div>

            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              <div className="flex flex-col items-start space-y-3 animate-fade-in" style={{ animationDelay: "0.1s" }}>
                <div className="rounded-full bg-primary/10 p-3">
                  <Zap className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Energy Efficiency</h3>
                <p className="text-muted-foreground">
                  Optimize traffic flow to reduce energy consumption and extend EV battery range by up to 15%.
                </p>
              </div>

              <div className="flex flex-col items-start space-y-3 animate-fade-in" style={{ animationDelay: "0.2s" }}>
                <div className="rounded-full bg-primary/10 p-3">
                  <Globe className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Environmental Impact</h3>
                <p className="text-muted-foreground">
                  Reduce carbon emissions by minimizing idling time and optimizing traffic patterns.
                </p>
              </div>

              <div className="flex flex-col items-start space-y-3 animate-fade-in" style={{ animationDelay: "0.3s" }}>
                <div className="rounded-full bg-primary/10 p-3">
                  <TrendingUp className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Economic Benefits</h3>
                <p className="text-muted-foreground">
                  Save on fuel costs, reduce infrastructure wear, and increase productivity by reducing commute times.
                </p>
              </div>

              <div className="flex flex-col items-start space-y-3 animate-fade-in" style={{ animationDelay: "0.4s" }}>
                <div className="rounded-full bg-primary/10 p-3">
                  <Car className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">EV & AV Friendly</h3>
                <p className="text-muted-foreground">
                  Prioritize electric and autonomous vehicles to encourage adoption and maximize their benefits.
                </p>
              </div>

              <div className="flex flex-col items-start space-y-3 animate-fade-in" style={{ animationDelay: "0.5s" }}>
                <div className="rounded-full bg-primary/10 p-3">
                  <Cpu className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">AI-Powered Intelligence</h3>
                <p className="text-muted-foreground">
                  Leverage machine learning to continuously improve traffic prediction and optimization.
                </p>
              </div>

              <div className="flex flex-col items-start space-y-3 animate-fade-in" style={{ animationDelay: "0.6s" }}>
                <div className="rounded-full bg-primary/10 p-3">
                  <Battery className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Charging Network</h3>
                <p className="text-muted-foreground">
                  Integrated EV charging station finder with real-time availability and route planning.
                </p>
              </div>
            </div>

            <div className="flex justify-center mt-12">
              <Button
                asChild
                size="lg"
                className="bg-gradient-primary hover:opacity-90 transition-all btn-hover-effect"
              >
                <Link href="/dashboard">
                  Start Exploring <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t bg-background py-6">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="flex items-center gap-2">
            <Leaf className="h-6 w-6 text-primary" />
            <p className="text-sm text-muted-foreground">© 2025 Green Corridor System. All rights reserved.</p>
          </div>
          <div className="flex gap-4">
            <Link
              href="/terms"
              className="text-sm text-muted-foreground underline underline-offset-4 hover:text-primary transition-colors"
            >
              Terms of Service
            </Link>
            <Link
              href="/privacy"
              className="text-sm text-muted-foreground underline underline-offset-4 hover:text-primary transition-colors"
            >
              Privacy
            </Link>
            <Link
              href="/contact"
              className="text-sm text-muted-foreground underline underline-offset-4 hover:text-primary transition-colors"
            >
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

