"use client"

import { useEffect, useState, useRef } from "react"
import Link from "next/link"
import { Activity, Layers, Leaf, Maximize2, Minimize2, Settings, ZoomIn, ZoomOut, BatteryCharging } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { TrafficMapCanvas } from "@/components/traffic-map-canvas"
import { TrafficMapLegend } from "@/components/traffic-map-legend"
import { TrafficMapControls } from "@/components/traffic-map-controls"
import { ChatbotAssistant } from "@/components/chatbot-assistant"
import { EVChargingStations } from "@/components/ev-charging-stations"
import { generateTrafficMapData } from "@/lib/generate-data"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function TrafficMap() {
  const [mapData, setMapData] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [showChatbot, setShowChatbot] = useState(false)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [zoomLevel, setZoomLevel] = useState([1])
  const [showEVs, setShowEVs] = useState(true)
  const [showAVs, setShowAVs] = useState(true)
  const [showTraditional, setShowTraditional] = useState(true)
  const [selectedCity, setSelectedCity] = useState("metro-city")
  const [showChargingStations, setShowChargingStations] = useState(true)
  const [activeTab, setActiveTab] = useState("traffic")
  const mapContainerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Load data
    setIsLoading(true)
    setTimeout(() => {
      setMapData(generateTrafficMapData(selectedCity))
      setIsLoading(false)
    }, 1000)
  }, [selectedCity])

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      mapContainerRef.current?.requestFullscreen()
      setIsFullscreen(true)
    } else {
      document.exitFullscreen()
      setIsFullscreen(false)
    }
  }

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }

    document.addEventListener("fullscreenchange", handleFullscreenChange)
    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange)
    }
  }, [])

  // Calculate traffic statistics
  const getTrafficStats = () => {
    if (!mapData) return { total: 0, ev: 0, av: 0, traditional: 0 }

    const vehicles = mapData.vehicles || []
    const total = vehicles.length
    const ev = vehicles.filter((v: any) => v.type === "ev").length
    const av = vehicles.filter((v: any) => v.type === "av").length
    const traditional = vehicles.filter((v: any) => v.type === "traditional").length

    return { total, ev, av, traditional }
  }

  const stats = getTrafficStats()

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
          <div className="flex gap-6 md:gap-10">
            <Link href="/" className="flex items-center space-x-2">
              <Leaf className="h-6 w-6 text-primary" />
              <span className="inline-block font-bold">Green Corridor System</span>
            </Link>
            <nav className="hidden gap-6 md:flex">
              <Link
                href="/dashboard"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Dashboard
              </Link>
              <Link href="/traffic-map" className="flex items-center text-sm font-medium text-primary">
                Traffic Map
              </Link>
              <Link
                href="/analytics"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Analytics
              </Link>
              <Link
                href="/settings"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Settings
              </Link>
            </nav>
          </div>
          <div className="flex flex-1 items-center justify-end space-x-4">
            <Button variant="outline" size="icon" onClick={() => setShowChatbot(!showChatbot)} className="relative">
              <Activity className="h-4 w-4" />
              <span className="sr-only">Toggle AI Assistant</span>
              {showChatbot && <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-primary"></span>}
            </Button>
            <Button variant="outline" size="icon" asChild>
              <Link href="/settings">
                <Settings className="h-4 w-4" />
                <span className="sr-only">Settings</span>
              </Link>
            </Button>
            <Button variant="outline" size="sm">
              Admin
            </Button>
          </div>
        </div>
      </header>
      <main className="flex-1 p-4 md:p-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">
              Traffic Map
            </h1>
            <p className="text-sm text-muted-foreground">Real-time visualization of traffic flow and corridor status</p>
          </div>
          <div className="flex items-center gap-4">
            <Select value={selectedCity} onValueChange={setSelectedCity}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select city" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="metro-city">Metro City</SelectItem>
                <SelectItem value="downtown">Downtown</SelectItem>
                <SelectItem value="suburban">Suburban Area</SelectItem>
                <SelectItem value="industrial">Industrial Zone</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="bg-muted/50 p-1">
            <TabsTrigger
              value="traffic"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary/80 data-[state=active]:to-secondary/80 data-[state=active]:text-white"
            >
              Traffic Flow
            </TabsTrigger>
            <TabsTrigger
              value="charging"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary/80 data-[state=active]:to-secondary/80 data-[state=active]:text-white"
            >
              EV Charging Stations
            </TabsTrigger>
          </TabsList>

          <TabsContent value="traffic" className="space-y-4">
            <div className="grid gap-6 md:grid-cols-[300px_1fr]">
              <div className="space-y-6">
                <Card className="border-2 border-primary/10 shadow-md bg-gradient-to-br from-background to-muted/30">
                  <CardHeader>
                    <CardTitle>Map Controls</CardTitle>
                    <CardDescription>Adjust map view and filters</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="zoom">Zoom Level</Label>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => setZoomLevel([Math.max(0.5, zoomLevel[0] - 0.1)])}
                          >
                            <ZoomOut className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => setZoomLevel([Math.min(2, zoomLevel[0] + 0.1)])}
                          >
                            <ZoomIn className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <Slider id="zoom" min={0.5} max={2} step={0.1} value={zoomLevel} onValueChange={setZoomLevel} />
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-sm font-medium">Vehicle Filters</h3>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="show-evs">Electric Vehicles</Label>
                        <Switch id="show-evs" checked={showEVs} onCheckedChange={setShowEVs} />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="show-avs">Autonomous Vehicles</Label>
                        <Switch id="show-avs" checked={showAVs} onCheckedChange={setShowAVs} />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="show-traditional">Traditional Vehicles</Label>
                        <Switch id="show-traditional" checked={showTraditional} onCheckedChange={setShowTraditional} />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="show-charging-stations" className="flex items-center gap-1">
                          <BatteryCharging className="h-4 w-4 text-primary" />
                          Charging Stations
                        </Label>
                        <Switch
                          id="show-charging-stations"
                          checked={showChargingStations}
                          onCheckedChange={setShowChargingStations}
                        />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-sm font-medium">Map Layers</h3>
                      <TrafficMapControls />
                    </div>

                    <Button
                      className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90"
                      onClick={toggleFullscreen}
                    >
                      {isFullscreen ? (
                        <>
                          <Minimize2 className="mr-2 h-4 w-4" /> Exit Fullscreen
                        </>
                      ) : (
                        <>
                          <Maximize2 className="mr-2 h-4 w-4" /> Fullscreen
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>

                <Card className="border-2 border-primary/10 shadow-md bg-gradient-to-br from-background to-muted/30">
                  <CardHeader>
                    <CardTitle>Traffic Statistics</CardTitle>
                    <CardDescription>Current vehicle distribution</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="rounded-md border p-3 text-center">
                        <div className="text-2xl font-bold">{stats.total}</div>
                        <p className="text-xs text-muted-foreground">Total Vehicles</p>
                      </div>
                      <div className="rounded-md border p-3 text-center bg-blue-500/10">
                        <div className="text-2xl font-bold">{stats.ev}</div>
                        <p className="text-xs text-muted-foreground">Electric Vehicles</p>
                      </div>
                      <div className="rounded-md border p-3 text-center bg-purple-500/10">
                        <div className="text-2xl font-bold">{stats.av}</div>
                        <p className="text-xs text-muted-foreground">Autonomous Vehicles</p>
                      </div>
                      <div className="rounded-md border p-3 text-center bg-gray-500/10">
                        <div className="text-2xl font-bold">{stats.traditional}</div>
                        <p className="text-xs text-muted-foreground">Traditional Vehicles</p>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Traffic Density</span>
                        <Badge variant="outline" className="bg-green-500/10 text-green-500">
                          Low
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Signal Efficiency</span>
                        <Badge variant="outline" className="bg-green-500/10 text-green-500">
                          92%
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Flow Rate</span>
                        <Badge variant="outline" className="bg-green-500/10 text-green-500">
                          Optimal
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 border-primary/10 shadow-md bg-gradient-to-br from-background to-muted/30">
                  <CardHeader>
                    <CardTitle>Legend</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <TrafficMapLegend />
                  </CardContent>
                </Card>
              </div>

              <div
                ref={mapContainerRef}
                className="relative rounded-lg border overflow-hidden"
                style={{ height: "70vh" }}
              >
                <div className="absolute top-4 right-4 z-10">
                  <Button variant="outline" size="icon" className="bg-background/80 backdrop-blur-sm">
                    <Layers className="h-4 w-4" />
                  </Button>
                </div>
                <TrafficMapCanvas
                  isLoading={isLoading}
                  data={mapData}
                  zoomLevel={zoomLevel[0]}
                  showEVs={showEVs}
                  showAVs={showAVs}
                  showTraditional={showTraditional}
                  showChargingStations={showChargingStations}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="charging" className="space-y-4">
            <EVChargingStations />
          </TabsContent>
        </Tabs>
      </main>
      {showChatbot && <ChatbotAssistant onClose={() => setShowChatbot(false)} />}
    </div>
  )
}

