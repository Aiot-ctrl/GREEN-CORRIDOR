"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Activity, BarChart3, Calendar, Download, FileText, Leaf, RefreshCw, Settings, Share2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DatePickerWithRange } from "@/components/date-range-picker"
import { AIInsightsPanel } from "@/components/ai-insights-panel"
import { PredictiveAnalyticsChart } from "@/components/predictive-analytics-chart"
import { CorridorComparisonChart } from "@/components/corridor-comparison-chart"
import { EmissionsReductionChart } from "@/components/emissions-reduction-chart"
import { VehicleTypePerformanceChart } from "@/components/vehicle-type-performance-chart"
import { ChatbotAssistant } from "@/components/chatbot-assistant"
import { generateAnalyticsData } from "@/lib/generate-data"
import { Badge } from "@/components/ui/badge"

export default function Analytics() {
  const [analyticsData, setAnalyticsData] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [timeRange, setTimeRange] = useState("30d")
  const [showChatbot, setShowChatbot] = useState(false)
  const [selectedCorridors, setSelectedCorridors] = useState(["all"])

  useEffect(() => {
    // Simulate loading data
    setIsLoading(true)
    setTimeout(() => {
      setAnalyticsData(generateAnalyticsData(timeRange))
      setIsLoading(false)
    }, 1000)
  }, [timeRange])

  const refreshData = () => {
    setIsLoading(true)
    setTimeout(() => {
      setAnalyticsData(generateAnalyticsData(timeRange))
      setIsLoading(false)
    }, 1000)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
          <div className="flex gap-6 md:gap-10">
            <Link href="/" className="flex items-center space-x-2">
              <Leaf className="h-6 w-6 text-primary" />
              <span className="inline-block font-bold">Green Corridor System</span>
            </Link>
            <nav className="hidden gap-6 md:flex">
              <Link
                href="/dashboard"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Dashboard
              </Link>
              <Link
                href="/traffic-map"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Traffic Map
              </Link>
              <Link href="/analytics" className="flex items-center text-sm font-medium text-primary">
                Analytics
              </Link>
              <Link
                href="/settings"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Settings
              </Link>
            </nav>
          </div>
          <div className="flex flex-1 items-center justify-end space-x-4">
            <Button variant="outline" size="icon" onClick={() => setShowChatbot(!showChatbot)} className="relative">
              <Activity className="h-4 w-4" />
              <span className="sr-only">Toggle AI Assistant</span>
              {showChatbot && <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-primary"></span>}
            </Button>
            <Button variant="outline" size="icon" asChild>
              <Link href="/settings">
                <Settings className="h-4 w-4" />
                <span className="sr-only">Settings</span>
              </Link>
            </Button>
            <Button variant="outline" size="sm">
              Admin
            </Button>
          </div>
        </div>
      </header>
      <main className="flex-1 p-4 md:p-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-bold">Analytics & Insights</h1>
            <p className="text-muted-foreground">Analyze performance metrics and AI-powered insights</p>
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <DatePickerWithRange />
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select time range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Last 7 Days</SelectItem>
                <SelectItem value="30d">Last 30 Days</SelectItem>
                <SelectItem value="90d">Last 90 Days</SelectItem>
                <SelectItem value="1y">Last Year</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="icon" onClick={refreshData} disabled={isLoading}>
              <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
              <span className="sr-only">Refresh</span>
            </Button>
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
            <Button>
              <FileText className="mr-2 h-4 w-4" />
              Generate Report
            </Button>
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-3 mb-6">
          <Card className="border-2 border-primary/10 shadow-md">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Traffic Efficiency Improvement</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">+24.8%</div>
              <p className="text-xs text-muted-foreground">+5.2% from previous period</p>
              <div className="mt-4 h-1 w-full bg-muted overflow-hidden rounded-full">
                <div className="bg-primary h-1 w-[75%]" />
              </div>
            </CardContent>
          </Card>
          <Card className="border-2 border-primary/10 shadow-md">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Energy Savings</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12,450 kWh</div>
              <p className="text-xs text-muted-foreground">Equivalent to 8.2 tons of CO₂</p>
              <div className="mt-4 h-1 w-full bg-muted overflow-hidden rounded-full">
                <div className="bg-primary h-1 w-[82%]" />
              </div>
            </CardContent>
          </Card>
          <Card className="border-2 border-primary/10 shadow-md">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">AI Model Accuracy</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">94.7%</div>
              <p className="text-xs text-muted-foreground">+2.3% from previous calibration</p>
              <div className="mt-4 h-1 w-full bg-muted overflow-hidden rounded-full">
                <div className="bg-primary h-1 w-[94%]" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 md:grid-cols-3 mb-6">
          <Card className="md:col-span-2 border-2 border-primary/10 shadow-md">
            <CardHeader>
              <CardTitle>AI Insights</CardTitle>
              <CardDescription>AI-generated insights based on current traffic patterns</CardDescription>
            </CardHeader>
            <CardContent>
              <AIInsightsPanel isLoading={isLoading} data={analyticsData?.aiInsights} />
            </CardContent>
          </Card>
          <Card className="border-2 border-primary/10 shadow-md">
            <CardHeader>
              <CardTitle>Upcoming Events</CardTitle>
              <CardDescription>Events that may impact traffic patterns</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="rounded-md bg-primary/10 p-2">
                    <Calendar className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium">Downtown Festival</h3>
                    <p className="text-sm text-muted-foreground">March 20-22, 2025</p>
                    <p className="text-sm mt-1">Expected 30% increase in traffic volume</p>
                    <Badge className="mt-2 bg-yellow-500/20 text-yellow-700 hover:bg-yellow-500/30">High Impact</Badge>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="rounded-md bg-primary/10 p-2">
                    <Calendar className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium">Road Construction</h3>
                    <p className="text-sm text-muted-foreground">April 5-15, 2025</p>
                    <p className="text-sm mt-1">Main Street corridor partial closure</p>
                    <Badge className="mt-2 bg-red-500/20 text-red-700 hover:bg-red-500/30">Critical</Badge>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="rounded-md bg-primary/10 p-2">
                    <Calendar className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium">System Maintenance</h3>
                    <p className="text-sm text-muted-foreground">March 18, 2025</p>
                    <p className="text-sm mt-1">Scheduled 2-hour maintenance window</p>
                    <Badge className="mt-2 bg-blue-500/20 text-blue-700 hover:bg-blue-500/30">Low Impact</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="predictive">
          <TabsList className="mb-4">
            <TabsTrigger value="predictive">Predictive Analytics</TabsTrigger>
            <TabsTrigger value="corridor">Corridor Comparison</TabsTrigger>
            <TabsTrigger value="emissions">Emissions Reduction</TabsTrigger>
            <TabsTrigger value="vehicle">Vehicle Performance</TabsTrigger>
          </TabsList>
          <TabsContent value="predictive" className="space-y-4">
            <Card className="border-2 border-primary/10 shadow-md">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Traffic Prediction</CardTitle>
                    <CardDescription>AI-powered traffic volume prediction for the next 7 days</CardDescription>
                  </div>
                  <Button variant="outline" size="sm">
                    <Share2 className="mr-2 h-4 w-4" />
                    Share
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <PredictiveAnalyticsChart isLoading={isLoading} data={analyticsData?.predictiveAnalytics} />
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="corridor" className="space-y-4">
            <Card className="border-2 border-primary/10 shadow-md">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Corridor Comparison</CardTitle>
                    <CardDescription>Performance comparison across different corridors</CardDescription>
                  </div>
                  <Select value={selectedCorridors[0]} onValueChange={(value) => setSelectedCorridors([value])}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Select corridors" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Corridors</SelectItem>
                      <SelectItem value="main-street">Main Street</SelectItem>
                      <SelectItem value="downtown">Downtown</SelectItem>
                      <SelectItem value="university">University Ave</SelectItem>
                      <SelectItem value="industrial">Industrial Zone</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent>
                <CorridorComparisonChart
                  isLoading={isLoading}
                  data={analyticsData?.corridorComparison}
                  selectedCorridors={selectedCorridors}
                />
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="emissions" className="space-y-4">
            <Card className="border-2 border-primary/10 shadow-md">
              <CardHeader>
                <CardTitle>Emissions Reduction</CardTitle>
                <CardDescription>Estimated CO₂ emissions reduction from system implementation</CardDescription>
              </CardHeader>
              <CardContent>
                <EmissionsReductionChart isLoading={isLoading} data={analyticsData?.emissionsReduction} />
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="vehicle" className="space-y-4">
            <Card className="border-2 border-primary/10 shadow-md">
              <CardHeader>
                <CardTitle>Vehicle Type Performance</CardTitle>
                <CardDescription>Performance metrics by vehicle type</CardDescription>
              </CardHeader>
              <CardContent>
                <VehicleTypePerformanceChart isLoading={isLoading} data={analyticsData?.vehicleTypePerformance} />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
      {showChatbot && <ChatbotAssistant onClose={() => setShowChatbot(false)} />}
    </div>
  )
}

