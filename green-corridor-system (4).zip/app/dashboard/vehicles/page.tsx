"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import {
  Activity,
  BarChart3,
  Battery,
  Car,
  Clock,
  Download,
  Leaf,
  MapPin,
  Settings,
  Zap,
  ArrowUpDown,
  Filter,
  Search,
  BatteryCharging,
  Gauge,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Skeleton } from "@/components/ui/skeleton"
import { VehicleDistributionChart } from "@/components/vehicle-distribution-chart"
import { generateTrafficData } from "@/lib/generate-data"
import { toast } from "@/hooks/use-toast"
import { ToastAction } from "@/components/ui/toast"
import {
  Chart,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  XAxis,
  YAxis,
  Line,
  LineChart,
} from "@/components/ui/chart"

export default function VehiclesPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [vehicleData, setVehicleData] = useState<any>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [sortBy, setSortBy] = useState("id")
  const [sortOrder, setSortOrder] = useState("asc")
  const [filterType, setFilterType] = useState("all")

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true)
      try {
        // Simulate API call
        setTimeout(() => {
          const data = generateTrafficData()
          setVehicleData(data)
          setIsLoading(false)
        }, 1000)
      } catch (error) {
        console.error("Error loading vehicle data:", error)
        toast({
          variant: "destructive",
          title: "Error loading data",
          description: "There was a problem loading the vehicle data. Please try again.",
          action: <ToastAction altText="Try again">Try again</ToastAction>,
        })
        setIsLoading(false)
      }
    }

    loadData()
  }, [])

  // Generate vehicle trend data
  const generateVehicleTrendData = () => {
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    const data = []

    for (let i = 0; i < 12; i++) {
      const month = months[i]
      const ev = 10 + i * 2 + Math.floor(Math.random() * 5)
      const av = 5 + i * 1.5 + Math.floor(Math.random() * 3)
      const traditional = 85 - ev - av + Math.floor(Math.random() * 5)

      data.push({
        month,
        ev,
        av,
        traditional,
      })
    }

    return data
  }

  const vehicleTrendData = generateVehicleTrendData()

  // Generate vehicle list data
  const generateVehicleListData = () => {
    const vehicleTypes = ["Electric", "Autonomous", "Traditional"]
    const statuses = ["Active", "Idle", "Charging", "Maintenance"]
    const models = [
      "Tesla Model 3",
      "Nissan Leaf",
      "Toyota Prius",
      "Waymo Self-Driving",
      "Ford F-150",
      "Chevy Bolt",
      "Honda Civic",
      "BMW i3",
      "Cruise AV",
      "Toyota Camry",
    ]
    const vehicles = []

    for (let i = 1; i <= 50; i++) {
      const type = vehicleTypes[Math.floor(Math.random() * vehicleTypes.length)]
      const status = statuses[Math.floor(Math.random() * statuses.length)]
      const model = models[Math.floor(Math.random() * models.length)]
      const efficiency = Math.floor(Math.random() * 30) + 70
      const batteryLevel = type === "Electric" ? Math.floor(Math.random() * 100) : null
      const lastActive = `${Math.floor(Math.random() * 60)} mins ago`
      const mileage = Math.floor(Math.random() * 50000) + 10000
      const registrationDate = new Date(2022, Math.floor(Math.random() * 12), Math.floor(Math.random() * 28) + 1)
        .toISOString()
        .split("T")[0]

      vehicles.push({
        id: `VEH-${i.toString().padStart(3, "0")}`,
        type,
        model,
        status,
        efficiency,
        batteryLevel,
        lastActive,
        mileage,
        registrationDate,
      })
    }

    return vehicles
  }

  const vehicleListData = generateVehicleListData()

  // Filter, sort, and search vehicles
  const filteredVehicles = vehicleListData
    .filter((vehicle: any) => {
      const matchesSearch =
        vehicle.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        vehicle.model.toLowerCase().includes(searchQuery.toLowerCase())
      const matchesFilter = filterType === "all" || vehicle.type.toLowerCase() === filterType.toLowerCase()
      return matchesSearch && matchesFilter
    })
    .sort((a: any, b: any) => {
      const factor = sortOrder === "asc" ? 1 : -1
      if (sortBy === "id") {
        return a.id.localeCompare(b.id) * factor
      } else if (sortBy === "efficiency") {
        return (a.efficiency - b.efficiency) * factor
      } else if (sortBy === "mileage") {
        return (a.mileage - b.mileage) * factor
      }
      return 0
    })

  const handleSort = (column: string) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc")
    } else {
      setSortBy(column)
      setSortOrder("asc")
    }
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen flex-col">
        <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
            <div className="flex gap-6 md:gap-10">
              <Link href="/" className="flex items-center space-x-2">
                <Leaf className="h-6 w-6 text-primary" />
                <span className="inline-block font-bold">Green Corridor System</span>
              </Link>
            </div>
          </div>
        </header>
        <div className="grid flex-1 md:grid-cols-[240px_1fr]">
          <aside className="hidden border-r bg-muted/40 md:block">
            <div className="flex h-full max-h-screen flex-col gap-2">
              <div className="flex h-14 items-center border-b px-4">
                <Link href="/dashboard" className="flex items-center gap-2 font-semibold">
                  <BarChart3 className="h-6 w-6" />
                  <span>Dashboard</span>
                </Link>
              </div>
              <div className="flex-1 overflow-auto py-2">
                <nav className="grid items-start px-2 text-sm font-medium">
                  <Link
                    href="/dashboard"
                    className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                  >
                    <Activity className="h-4 w-4" />
                    Overview
                  </Link>
                  <Link
                    href="/dashboard/corridors"
                    className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                  >
                    <MapPin className="h-4 w-4" />
                    Corridors
                  </Link>
                  <Link
                    href="/dashboard/vehicles"
                    className="flex items-center gap-3 rounded-lg bg-primary/10 px-3 py-2 text-primary transition-all"
                  >
                    <Car className="h-4 w-4" />
                    Vehicles
                  </Link>
                  <Link
                    href="/dashboard/signals"
                    className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                  >
                    <Zap className="h-4 w-4" />
                    Traffic Signals
                  </Link>
                  <Link
                    href="/dashboard/energy"
                    className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                  >
                    <Battery className="h-4 w-4" />
                    Energy Savings
                  </Link>
                  <Link
                    href="/dashboard/reports"
                    className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                  >
                    <Download className="h-4 w-4" />
                    Reports
                  </Link>
                </nav>
              </div>
            </div>
          </aside>
          <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold">Vehicles</h1>
                <p className="text-sm text-muted-foreground">Manage and monitor vehicles in the system</p>
              </div>
            </div>
            <div className="space-y-4">
              <Skeleton className="h-[300px] w-full" />
              <div className="grid gap-4 md:grid-cols-3">
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-24 w-full" />
              </div>
              <Skeleton className="h-[400px] w-full" />
            </div>
          </main>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
          <div className="flex gap-6 md:gap-10">
            <Link href="/" className="flex items-center space-x-2">
              <Leaf className="h-6 w-6 text-primary" />
              <span className="inline-block font-bold">Green Corridor System</span>
            </Link>
            <nav className="hidden gap-6 md:flex">
              <Link
                href="/dashboard"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Dashboard
              </Link>
              <Link
                href="/traffic-map"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Traffic Map
              </Link>
              <Link
                href="/analytics"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Analytics
              </Link>
              <Link
                href="/settings"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Settings
              </Link>
            </nav>
          </div>
          <div className="flex flex-1 items-center justify-end space-x-4">
            <Button variant="outline" size="icon" asChild>
              <Link href="/settings">
                <Settings className="h-4 w-4" />
                <span className="sr-only">Settings</span>
              </Link>
            </Button>
            <Button variant="outline" size="sm">
              Admin
            </Button>
          </div>
        </div>
      </header>
      <div className="grid flex-1 md:grid-cols-[240px_1fr]">
        <aside className="hidden border-r bg-muted/40 md:block">
          <div className="flex h-full max-h-screen flex-col gap-2">
            <div className="flex h-14 items-center border-b px-4">
              <Link href="/dashboard" className="flex items-center gap-2 font-semibold">
                <BarChart3 className="h-6 w-6" />
                <span>Dashboard</span>
              </Link>
            </div>
            <div className="flex-1 overflow-auto py-2">
              <nav className="grid items-start px-2 text-sm font-medium">
                <Link
                  href="/dashboard"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                >
                  <Activity className="h-4 w-4" />
                  Overview
                </Link>
                <Link
                  href="/dashboard/corridors"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                >
                  <MapPin className="h-4 w-4" />
                  Corridors
                </Link>
                <Link
                  href="/dashboard/vehicles"
                  className="flex items-center gap-3 rounded-lg bg-primary/10 px-3 py-2 text-primary transition-all"
                >
                  <Car className="h-4 w-4" />
                  Vehicles
                </Link>
                <Link
                  href="/dashboard/signals"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                >
                  <Zap className="h-4 w-4" />
                  Traffic Signals
                </Link>
                <Link
                  href="/dashboard/energy"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                >
                  <Battery className="h-4 w-4" />
                  Energy Savings
                </Link>
                <Link
                  href="/dashboard/reports"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                >
                  <Download className="h-4 w-4" />
                  Reports
                </Link>
              </nav>
            </div>
          </div>
        </aside>
        <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">
                Vehicles
              </h1>
              <p className="text-sm text-muted-foreground">Manage and monitor vehicles in the system</p>
            </div>
            <Button className="bg-gradient-to-r from-primary to-secondary hover:opacity-90 transition-all">
              <Car className="mr-2 h-4 w-4" />
              Add New Vehicle
            </Button>
          </div>

          <Card className="border-2 border-primary/10 shadow-md">
            <CardHeader>
              <CardTitle>Vehicle Distribution</CardTitle>
              <CardDescription>Breakdown of vehicle types and adoption trends</CardDescription>
            </CardHeader>
            <CardContent>
              <VehicleDistributionChart isLoading={false} data={vehicleData?.vehicleDistribution} />
            </CardContent>
          </Card>

          <Card className="border-2 border-primary/10 shadow-md">
            <CardHeader>
              <CardTitle>Vehicle Type Trends</CardTitle>
              <CardDescription>Monthly trends in vehicle type distribution</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer className="h-[300px]">
                <Chart className="h-full">
                  <XAxis dataKey="month" tickLine={false} axisLine={false} fontSize={12} tickMargin={12} />
                  <YAxis
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(value) => `${value}%`}
                    fontSize={12}
                    tickMargin={12}
                  />
                  <ChartTooltip
                    content={
                      <ChartTooltipContent
                        className="border-none bg-background/80 backdrop-blur-sm"
                        valueFormatter={(value) => `${value}%`}
                      />
                    }
                  />
                  <LineChart data={vehicleTrendData}>
                    <Line dataKey="ev" stroke="#3b82f6" strokeWidth={2} />
                    <Line dataKey="av" stroke="#8b5cf6" strokeWidth={2} />
                    <Line dataKey="traditional" stroke="#6b7280" strokeWidth={2} />
                  </LineChart>
                </Chart>
              </ChartContainer>
              <div className="flex justify-between text-xs text-muted-foreground mt-2">
                <div className="flex items-center gap-1">
                  <div className="w-3 h-1 bg-[#3b82f6]"></div>
                  <span>Electric Vehicles</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-3 h-1 bg-[#8b5cf6]"></div>
                  <span>Autonomous Vehicles</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-3 h-1 bg-[#6b7280]"></div>
                  <span>Traditional Vehicles</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-3">
            <Card className="border-2 border-primary/10 shadow-md">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Vehicles</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{vehicleListData.length}</div>
                <p className="text-xs text-muted-foreground">Registered in the system</p>
                <div className="mt-2 h-1 w-full bg-muted overflow-hidden rounded-full">
                  <div className="bg-gradient-to-r from-primary to-secondary h-1 w-full" />
                </div>
              </CardContent>
            </Card>
            <Card className="border-2 border-primary/10 shadow-md">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Vehicle Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    <span className="text-xs">Active</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                    <span className="text-xs">Idle</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                    <span className="text-xs">Charging</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-red-500"></div>
                    <span className="text-xs">Maintenance</span>
                  </div>
                </div>
                <div className="flex mt-2 h-2 w-full overflow-hidden rounded-full">
                  <div
                    className="bg-green-500 h-2"
                    style={{
                      width: `${
                        (vehicleListData.filter((v: any) => v.status === "Active").length / vehicleListData.length) *
                        100
                      }%`,
                    }}
                  ></div>
                  <div
                    className="bg-blue-500 h-2"
                    style={{
                      width: `${
                        (vehicleListData.filter((v: any) => v.status === "Idle").length / vehicleListData.length) * 100
                      }%`,
                    }}
                  ></div>
                  <div
                    className="bg-yellow-500 h-2"
                    style={{
                      width: `${
                        (vehicleListData.filter((v: any) => v.status === "Charging").length / vehicleListData.length) *
                        100
                      }%`,
                    }}
                  ></div>
                  <div
                    className="bg-red-500 h-2"
                    style={{
                      width: `${
                        (vehicleListData.filter((v: any) => v.status === "Maintenance").length /
                          vehicleListData.length) *
                        100
                      }%`,
                    }}
                  ></div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-2 border-primary/10 shadow-md">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Average Efficiency</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {Math.round(
                    vehicleListData.reduce((sum: number, vehicle: any) => sum + vehicle.efficiency, 0) /
                      vehicleListData.length,
                  )}
                  %
                </div>
                <p className="text-xs text-muted-foreground">Across all vehicles</p>
                <div className="mt-2 h-1 w-full bg-muted overflow-hidden rounded-full">
                  <div
                    className="bg-gradient-to-r from-primary to-secondary h-1"
                    style={{
                      width: `${Math.round(
                        vehicleListData.reduce((sum: number, vehicle: any) => sum + vehicle.efficiency, 0) /
                          vehicleListData.length,
                      )}%`,
                    }}
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-2 border-primary/10 shadow-md">
            <CardHeader>
              <CardTitle>Vehicle Management</CardTitle>
              <CardDescription>View and manage all vehicles in the system</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-4 mb-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search vehicles..."
                      className="pl-8"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger className="w-[180px]">
                      <Filter className="mr-2 h-4 w-4" />
                      <SelectValue placeholder="Filter by type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="electric">Electric</SelectItem>
                      <SelectItem value="autonomous">Autonomous</SelectItem>
                      <SelectItem value="traditional">Traditional</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[120px] cursor-pointer" onClick={() => handleSort("id")}>
                        <div className="flex items-center gap-1">
                          Vehicle ID
                          {sortBy === "id" && (
                            <ArrowUpDown className={`h-4 w-4 ${sortOrder === "desc" ? "rotate-180" : ""}`} />
                          )}
                        </div>
                      </TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Model</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="cursor-pointer" onClick={() => handleSort("efficiency")}>
                        <div className="flex items-center gap-1">
                          Efficiency
                          {sortBy === "efficiency" && (
                            <ArrowUpDown className={`h-4 w-4 ${sortOrder === "desc" ? "rotate-180" : ""}`} />
                          )}
                        </div>
                      </TableHead>
                      <TableHead>Battery</TableHead>
                      <TableHead className="cursor-pointer" onClick={() => handleSort("mileage")}>
                        <div className="flex items-center gap-1">
                          Mileage
                          {sortBy === "mileage" && (
                            <ArrowUpDown className={`h-4 w-4 ${sortOrder === "desc" ? "rotate-180" : ""}`} />
                          )}
                        </div>
                      </TableHead>
                      <TableHead>Last Active</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredVehicles.map((vehicle: any) => (
                      <TableRow key={vehicle.id}>
                        <TableCell className="font-medium">{vehicle.id}</TableCell>
                        <TableCell>
                          <Badge
                            className={
                              vehicle.type === "Electric"
                                ? "bg-blue-500/20 text-blue-700 hover:bg-blue-500/30"
                                : vehicle.type === "Autonomous"
                                  ? "bg-purple-500/20 text-purple-700 hover:bg-purple-500/30"
                                  : "bg-gray-500/20 text-gray-700 hover:bg-gray-500/30"
                            }
                          >
                            {vehicle.type}
                          </Badge>
                        </TableCell>
                        <TableCell>{vehicle.model}</TableCell>
                        <TableCell>
                          <Badge
                            className={
                              vehicle.status === "Active"
                                ? "bg-green-500/20 text-green-700 hover:bg-green-500/30"
                                : vehicle.status === "Idle"
                                  ? "bg-blue-500/20 text-blue-700 hover:bg-blue-500/30"
                                  : vehicle.status === "Charging"
                                    ? "bg-yellow-500/20 text-yellow-700 hover:bg-yellow-500/30"
                                    : "bg-red-500/20 text-red-700 hover:bg-red-500/30"
                            }
                          >
                            {vehicle.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <span>{vehicle.efficiency}%</span>
                            <Progress
                              value={vehicle.efficiency}
                              className="h-1.5 w-16"
                              indicatorClassName={
                                vehicle.efficiency >= 90
                                  ? "bg-green-500"
                                  : vehicle.efficiency >= 75
                                    ? "bg-yellow-500"
                                    : "bg-red-500"
                              }
                            />
                          </div>
                        </TableCell>
                        <TableCell>
                          {vehicle.batteryLevel !== null ? (
                            <div className="flex items-center gap-2">
                              <BatteryCharging className="h-4 w-4 text-primary" />
                              <span>{vehicle.batteryLevel}%</span>
                            </div>
                          ) : (
                            <span className="text-muted-foreground">N/A</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Gauge className="h-4 w-4 text-muted-foreground" />
                            <span>{vehicle.mileage.toLocaleString()} mi</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span>{vehicle.lastActive}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="outline" size="sm" className="mr-2">
                            View
                          </Button>
                          <Button variant="outline" size="sm" className="border-primary/20 hover:bg-primary/10">
                            Edit
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  )
}

