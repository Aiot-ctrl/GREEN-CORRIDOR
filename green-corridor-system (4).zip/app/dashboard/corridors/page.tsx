"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import {
  Activity,
  BarChart3,
  Battery,
  Car,
  Download,
  Leaf,
  MapPin,
  Settings,
  Zap,
  ArrowUpDown,
  Filter,
  Search,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Skeleton } from "@/components/ui/skeleton"
import { CorridorPerformanceChart } from "@/components/corridor-performance-chart"
import { generateTrafficData } from "@/lib/generate-data"
import { toast } from "@/hooks/use-toast"
import { ToastAction } from "@/components/ui/toast"

export default function CorridorsPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [corridorData, setCorridorData] = useState<any>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [sortBy, setSortBy] = useState("name")
  const [sortOrder, setSortOrder] = useState("asc")
  const [filterStatus, setFilterStatus] = useState("all")

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true)
      try {
        // Simulate API call
        setTimeout(() => {
          const data = generateTrafficData()
          setCorridorData(data)
          setIsLoading(false)
        }, 1000)
      } catch (error) {
        console.error("Error loading corridor data:", error)
        toast({
          variant: "destructive",
          title: "Error loading data",
          description: "There was a problem loading the corridor data. Please try again.",
          action: <ToastAction altText="Try again">Try again</ToastAction>,
        })
        setIsLoading(false)
      }
    }

    loadData()
  }, [])

  // Generate extended corridor data
  const getExtendedCorridorData = () => {
    if (!corridorData || !corridorData.corridorPerformance) return []

    return corridorData.corridorPerformance.map((corridor: any) => ({
      ...corridor,
      status: corridor.efficiency >= 90 ? "optimal" : corridor.efficiency >= 75 ? "moderate" : "congested",
      trafficVolume: Math.floor(Math.random() * 1000) + 500,
      signalCount: Math.floor(Math.random() * 10) + 5,
      lastUpdated: `${Math.floor(Math.random() * 10) + 1} mins ago`,
      energySavings: Math.floor(Math.random() * 200) + 50,
    }))
  }

  const extendedCorridorData = getExtendedCorridorData()

  // Filter, sort, and search corridors
  const filteredCorridors = extendedCorridorData
    .filter((corridor: any) => {
      const matchesSearch = corridor.name.toLowerCase().includes(searchQuery.toLowerCase())
      const matchesFilter = filterStatus === "all" || corridor.status === filterStatus
      return matchesSearch && matchesFilter
    })
    .sort((a: any, b: any) => {
      const factor = sortOrder === "asc" ? 1 : -1
      if (sortBy === "name") {
        return a.name.localeCompare(b.name) * factor
      } else if (sortBy === "efficiency") {
        return (a.efficiency - b.efficiency) * factor
      } else if (sortBy === "trafficVolume") {
        return (a.trafficVolume - b.trafficVolume) * factor
      }
      return 0
    })

  const handleSort = (column: string) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc")
    } else {
      setSortBy(column)
      setSortOrder("asc")
    }
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen flex-col">
        <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
            <div className="flex gap-6 md:gap-10">
              <Link href="/" className="flex items-center space-x-2">
                <Leaf className="h-6 w-6 text-primary" />
                <span className="inline-block font-bold">Green Corridor System</span>
              </Link>
            </div>
          </div>
        </header>
        <div className="grid flex-1 md:grid-cols-[240px_1fr]">
          <aside className="hidden border-r bg-muted/40 md:block">
            <div className="flex h-full max-h-screen flex-col gap-2">
              <div className="flex h-14 items-center border-b px-4">
                <Link href="/dashboard" className="flex items-center gap-2 font-semibold">
                  <BarChart3 className="h-6 w-6" />
                  <span>Dashboard</span>
                </Link>
              </div>
              <div className="flex-1 overflow-auto py-2">
                <nav className="grid items-start px-2 text-sm font-medium">
                  <Link
                    href="/dashboard"
                    className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                  >
                    <Activity className="h-4 w-4" />
                    Overview
                  </Link>
                  <Link
                    href="/dashboard/corridors"
                    className="flex items-center gap-3 rounded-lg bg-primary/10 px-3 py-2 text-primary transition-all"
                  >
                    <MapPin className="h-4 w-4" />
                    Corridors
                  </Link>
                  <Link
                    href="/dashboard/vehicles"
                    className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                  >
                    <Car className="h-4 w-4" />
                    Vehicles
                  </Link>
                  <Link
                    href="/dashboard/signals"
                    className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                  >
                    <Zap className="h-4 w-4" />
                    Traffic Signals
                  </Link>
                  <Link
                    href="/dashboard/energy"
                    className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                  >
                    <Battery className="h-4 w-4" />
                    Energy Savings
                  </Link>
                  <Link
                    href="/dashboard/reports"
                    className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                  >
                    <Download className="h-4 w-4" />
                    Reports
                  </Link>
                </nav>
              </div>
            </div>
          </aside>
          <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold">Corridors</h1>
                <p className="text-sm text-muted-foreground">Manage and monitor traffic corridors</p>
              </div>
            </div>
            <div className="space-y-4">
              <Skeleton className="h-[300px] w-full" />
              <div className="grid gap-4 md:grid-cols-3">
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-24 w-full" />
              </div>
              <Skeleton className="h-[400px] w-full" />
            </div>
          </main>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
          <div className="flex gap-6 md:gap-10">
            <Link href="/" className="flex items-center space-x-2">
              <Leaf className="h-6 w-6 text-primary" />
              <span className="inline-block font-bold">Green Corridor System</span>
            </Link>
            <nav className="hidden gap-6 md:flex">
              <Link
                href="/dashboard"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Dashboard
              </Link>
              <Link
                href="/traffic-map"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Traffic Map
              </Link>
              <Link
                href="/analytics"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Analytics
              </Link>
              <Link
                href="/settings"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Settings
              </Link>
            </nav>
          </div>
          <div className="flex flex-1 items-center justify-end space-x-4">
            <Button variant="outline" size="icon" asChild>
              <Link href="/settings">
                <Settings className="h-4 w-4" />
                <span className="sr-only">Settings</span>
              </Link>
            </Button>
            <Button variant="outline" size="sm">
              Admin
            </Button>
          </div>
        </div>
      </header>
      <div className="grid flex-1 md:grid-cols-[240px_1fr]">
        <aside className="hidden border-r bg-muted/40 md:block">
          <div className="flex h-full max-h-screen flex-col gap-2">
            <div className="flex h-14 items-center border-b px-4">
              <Link href="/dashboard" className="flex items-center gap-2 font-semibold">
                <BarChart3 className="h-6 w-6" />
                <span>Dashboard</span>
              </Link>
            </div>
            <div className="flex-1 overflow-auto py-2">
              <nav className="grid items-start px-2 text-sm font-medium">
                <Link
                  href="/dashboard"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                >
                  <Activity className="h-4 w-4" />
                  Overview
                </Link>
                <Link
                  href="/dashboard/corridors"
                  className="flex items-center gap-3 rounded-lg bg-primary/10 px-3 py-2 text-primary transition-all"
                >
                  <MapPin className="h-4 w-4" />
                  Corridors
                </Link>
                <Link
                  href="/dashboard/vehicles"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                >
                  <Car className="h-4 w-4" />
                  Vehicles
                </Link>
                <Link
                  href="/dashboard/signals"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                >
                  <Zap className="h-4 w-4" />
                  Traffic Signals
                </Link>
                <Link
                  href="/dashboard/energy"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                >
                  <Battery className="h-4 w-4" />
                  Energy Savings
                </Link>
                <Link
                  href="/dashboard/reports"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                >
                  <Download className="h-4 w-4" />
                  Reports
                </Link>
              </nav>
            </div>
          </div>
        </aside>
        <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">
                Corridors
              </h1>
              <p className="text-sm text-muted-foreground">Manage and monitor traffic corridors</p>
            </div>
            <Button className="bg-gradient-to-r from-primary to-secondary hover:opacity-90 transition-all">
              <MapPin className="mr-2 h-4 w-4" />
              Add New Corridor
            </Button>
          </div>

          <Card className="border-2 border-primary/10 shadow-md">
            <CardHeader>
              <CardTitle>Corridor Performance</CardTitle>
              <CardDescription>Efficiency metrics for each corridor in the system</CardDescription>
            </CardHeader>
            <CardContent>
              <CorridorPerformanceChart isLoading={false} data={corridorData?.corridorPerformance} />
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-3">
            <Card className="border-2 border-primary/10 shadow-md">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Corridors</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{extendedCorridorData.length}</div>
                <p className="text-xs text-muted-foreground">Active corridors in the system</p>
                <div className="mt-2 h-1 w-full bg-muted overflow-hidden rounded-full">
                  <div className="bg-gradient-to-r from-primary to-secondary h-1 w-full" />
                </div>
              </CardContent>
            </Card>
            <Card className="border-2 border-primary/10 shadow-md">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Average Efficiency</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {Math.round(
                    extendedCorridorData.reduce((sum: number, corridor: any) => sum + corridor.efficiency, 0) /
                      extendedCorridorData.length,
                  )}
                  %
                </div>
                <p className="text-xs text-muted-foreground">Across all corridors</p>
                <div className="mt-2 h-1 w-full bg-muted overflow-hidden rounded-full">
                  <div
                    className="bg-gradient-to-r from-primary to-secondary h-1"
                    style={{
                      width: `${Math.round(
                        extendedCorridorData.reduce((sum: number, corridor: any) => sum + corridor.efficiency, 0) /
                          extendedCorridorData.length,
                      )}%`,
                    }}
                  />
                </div>
              </CardContent>
            </Card>
            <Card className="border-2 border-primary/10 shadow-md">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Status Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    <span className="text-xs">Optimal</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                    <span className="text-xs">Moderate</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-red-500"></div>
                    <span className="text-xs">Congested</span>
                  </div>
                </div>
                <div className="flex mt-2 h-2 w-full overflow-hidden rounded-full">
                  <div
                    className="bg-green-500 h-2"
                    style={{
                      width: `${
                        (extendedCorridorData.filter((c: any) => c.status === "optimal").length /
                          extendedCorridorData.length) *
                        100
                      }%`,
                    }}
                  ></div>
                  <div
                    className="bg-yellow-500 h-2"
                    style={{
                      width: `${
                        (extendedCorridorData.filter((c: any) => c.status === "moderate").length /
                          extendedCorridorData.length) *
                        100
                      }%`,
                    }}
                  ></div>
                  <div
                    className="bg-red-500 h-2"
                    style={{
                      width: `${
                        (extendedCorridorData.filter((c: any) => c.status === "congested").length /
                          extendedCorridorData.length) *
                        100
                      }%`,
                    }}
                  ></div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-2 border-primary/10 shadow-md">
            <CardHeader>
              <CardTitle>Corridor Management</CardTitle>
              <CardDescription>View and manage all traffic corridors in the system</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-4 mb-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search corridors..."
                      className="pl-8"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-[180px]">
                      <Filter className="mr-2 h-4 w-4" />
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="optimal">Optimal</SelectItem>
                      <SelectItem value="moderate">Moderate</SelectItem>
                      <SelectItem value="congested">Congested</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[200px] cursor-pointer" onClick={() => handleSort("name")}>
                        <div className="flex items-center gap-1">
                          Corridor Name
                          {sortBy === "name" && (
                            <ArrowUpDown className={`h-4 w-4 ${sortOrder === "desc" ? "rotate-180" : ""}`} />
                          )}
                        </div>
                      </TableHead>
                      <TableHead className="cursor-pointer" onClick={() => handleSort("efficiency")}>
                        <div className="flex items-center gap-1">
                          Efficiency
                          {sortBy === "efficiency" && (
                            <ArrowUpDown className={`h-4 w-4 ${sortOrder === "desc" ? "rotate-180" : ""}`} />
                          )}
                        </div>
                      </TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="cursor-pointer" onClick={() => handleSort("trafficVolume")}>
                        <div className="flex items-center gap-1">
                          Traffic Volume
                          {sortBy === "trafficVolume" && (
                            <ArrowUpDown className={`h-4 w-4 ${sortOrder === "desc" ? "rotate-180" : ""}`} />
                          )}
                        </div>
                      </TableHead>
                      <TableHead>Signals</TableHead>
                      <TableHead>Energy Savings</TableHead>
                      <TableHead>Last Updated</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredCorridors.map((corridor: any) => (
                      <TableRow key={corridor.name}>
                        <TableCell className="font-medium">{corridor.name}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <span>{corridor.efficiency}%</span>
                            <Progress
                              value={corridor.efficiency}
                              className="h-1.5 w-16"
                              indicatorClassName={
                                corridor.efficiency >= 90
                                  ? "bg-green-500"
                                  : corridor.efficiency >= 75
                                    ? "bg-yellow-500"
                                    : "bg-red-500"
                              }
                            />
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge
                            className={
                              corridor.status === "optimal"
                                ? "bg-green-500/20 text-green-700 hover:bg-green-500/30"
                                : corridor.status === "moderate"
                                  ? "bg-yellow-500/20 text-yellow-700 hover:bg-yellow-500/30"
                                  : "bg-red-500/20 text-red-700 hover:bg-red-500/30"
                            }
                          >
                            {corridor.status === "optimal"
                              ? "Optimal"
                              : corridor.status === "moderate"
                                ? "Moderate"
                                : "Congested"}
                          </Badge>
                        </TableCell>
                        <TableCell>{corridor.trafficVolume} veh/h</TableCell>
                        <TableCell>{corridor.signalCount}</TableCell>
                        <TableCell>{corridor.energySavings} kWh</TableCell>
                        <TableCell>{corridor.lastUpdated}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="outline" size="sm" className="mr-2">
                            View
                          </Button>
                          <Button variant="outline" size="sm" className="border-primary/20 hover:bg-primary/10">
                            Edit
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  )
}

