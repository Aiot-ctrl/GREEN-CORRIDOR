"use client"

import { useState } from "react"
import Link from "next/link"
import { Activity, Leaf, Settings } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ReportGenerator } from "@/components/report-generator"
import { ChatbotAssistant } from "@/components/chatbot-assistant"

export default function ReportsPage() {
  const [showChatbot, setShowChatbot] = useState(false)

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
          <div className="flex gap-6 md:gap-10">
            <Link href="/" className="flex items-center space-x-2">
              <Leaf className="h-6 w-6 text-primary" />
              <span className="inline-block font-bold">Green Corridor System</span>
            </Link>
            <nav className="hidden gap-6 md:flex">
              <Link
                href="/dashboard"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Dashboard
              </Link>
              <Link
                href="/traffic-map"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Traffic Map
              </Link>
              <Link
                href="/analytics"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Analytics
              </Link>
              <Link href="/dashboard/reports" className="flex items-center text-sm font-medium text-primary">
                Reports
              </Link>
              <Link
                href="/settings"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Settings
              </Link>
            </nav>
          </div>
          <div className="flex flex-1 items-center justify-end space-x-4">
            <Button variant="outline" size="icon" onClick={() => setShowChatbot(!showChatbot)} className="relative">
              <Activity className="h-4 w-4" />
              <span className="sr-only">Toggle AI Assistant</span>
              {showChatbot && <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-primary"></span>}
            </Button>
            <Button variant="outline" size="icon" asChild>
              <Link href="/settings">
                <Settings className="h-4 w-4" />
                <span className="sr-only">Settings</span>
              </Link>
            </Button>
            <Button variant="outline" size="sm">
              Admin
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 p-4 md:p-8">
        <ReportGenerator />
      </main>

      {showChatbot && <ChatbotAssistant onClose={() => setShowChatbot(false)} />}
    </div>
  )
}

