"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import {
  Activity,
  BarChart3,
  Battery,
  Car,
  Clock,
  Download,
  Leaf,
  MapPin,
  Zap,
  ArrowUpDown,
  Search,
  Calendar,
  TrendingUp,
  Lightbulb,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { EnergySavingsChart } from "@/components/energy-savings-chart"
import { generateTrafficData } from "@/lib/generate-data"
import { toast } from "@/hooks/use-toast"
import { ToastAction } from "@/components/ui/toast"
import {
  Chart,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  XAxis,
  YAxis,
  Line,
  LineChart,
  Bar,
  BarChart,
} from "@/components/ui/chart"

export default function EnergyPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [energyData, setEnergyData] = useState<any>(null)
  const [timeRange, setTimeRange] = useState("30d")
  const [searchQuery, setSearchQuery] = useState("")
  const [sortBy, setSortBy] = useState("corridor")
  const [sortOrder, setSortOrder] = useState("asc")

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true)
      try {
        // Simulate API call
        setTimeout(() => {
          const data = generateTrafficData()
          setEnergyData(data)
          setIsLoading(false)
        }, 1000)
      } catch (error) {
        console.error("Error loading energy data:", error)
        toast({
          variant: "destructive",
          title: "Error loading data",
          description: "There was a problem loading the energy savings data. Please try again.",
          action: <ToastAction altText="Try again">Try again</ToastAction>,
        })
        setIsLoading(false)
      }
    }

    loadData()
  }, [])

  // Generate energy breakdown data
  const generateEnergyBreakdownData = () => {
    return [
      { category: "EV Battery Conservation", value: 65 },
      { category: "Reduced Idling Time", value: 25 },
      { category: "Optimized Acceleration", value: 10 },
    ]
  }

  const energyBreakdownData = generateEnergyBreakdownData()

  // Generate corridor energy data
  const generateCorridorEnergyData = () => {
    const corridors = ["Main Street", "Downtown", "University Ave", "Industrial Zone", "Suburban Area"]

    return corridors.map((corridor) => ({
      corridor,
      energySaved: Math.floor(Math.random() * 500) + 100,
      co2Reduction: Math.floor(Math.random() * 350) + 70,
      percentImprovement: Math.floor(Math.random() * 30) + 10,
      lastUpdated: `${Math.floor(Math.random() * 60)} mins ago`,
    }))
  }

  const corridorEnergyData = generateCorridorEnergyData()

  // Generate monthly trend data
  const generateMonthlyTrendData = () => {
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    return months.map((month) => ({
      month,
      energySaved: Math.floor(Math.random() * 1000) + 500,
      target: Math.floor(Math.random() * 800) + 600,
    }))
  }

  const monthlyTrendData = generateMonthlyTrendData()

  // Filter, sort, and search corridors
  const filteredCorridors = corridorEnergyData
    .filter((corridor: any) => {
      return corridor.corridor.toLowerCase().includes(searchQuery.toLowerCase())
    })
    .sort((a: any, b: any) => {
      const factor = sortOrder === "asc" ? 1 : -1
      if (sortBy === "corridor") {
        return a.corridor.localeCompare(b.corridor) * factor
      } else if (sortBy === "energySaved") {
        return (a.energySaved - b.energySaved) * factor
      } else if (sortBy === "percentImprovement") {
        return (a.percentImprovement - b.percentImprovement) * factor
      }
      return 0
    })

  const handleSort = (column: string) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc")
    } else {
      setSortBy(column)
      setSortOrder("asc")
    }
  }

  // Calculate total energy saved
  const totalEnergySaved = corridorEnergyData.reduce((sum, corridor) => sum + corridor.energySaved, 0)

  // Calculate total CO2 reduction
  const totalCO2Reduction = corridorEnergyData.reduce((sum, corridor) => sum + corridor.co2Reduction, 0)

  // Calculate trees equivalent (rough estimate: 20 kg CO2 per tree per year)
  const treesEquivalent = Math.round(totalCO2Reduction / 20)

  if (isLoading) {
    return (
      <div className="flex min-h-screen flex-col">
        <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
            <div className="flex gap-6 md:gap-10">
              <Link href="/" className="flex items-center space-x-2">
                <Leaf className="h-6 w-6 text-primary" />
                <span className="inline-block font-bold">Green Corridor System</span>
              </Link>
            </div>
          </div>
        </header>
        <div className="grid flex-1 md:grid-cols-[240px_1fr]">
          <aside className="hidden border-r bg-muted/40 md:block">
            <div className="flex h-full max-h-screen flex-col gap-2">
              <div className="flex h-14 items-center border-b px-4">
                <Link href="/dashboard" className="flex items-center gap-2 font-semibold">
                  <BarChart3 className="h-6 w-6" />
                  <span>Dashboard</span>
                </Link>
              </div>
              <div className="flex-1 overflow-auto py-2">
                <nav className="grid items-start px-2 text-sm font-medium">
                  <Link
                    href="/dashboard"
                    className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                  >
                    <Activity className="h-4 w-4" />
                    Overview
                  </Link>
                  <Link
                    href="/dashboard/corridors"
                    className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                  >
                    <MapPin className="h-4 w-4" />
                    Corridors
                  </Link>
                  <Link
                    href="/dashboard/vehicles"
                    className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                  >
                    <Car className="h-4 w-4" />
                    Vehicles
                  </Link>
                  <Link
                    href="/dashboard/signals"
                    className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                  >
                    <Zap className="h-4 w-4" />
                    Traffic Signals
                  </Link>
                  <Link
                    href="/dashboard/energy"
                    className="flex items-center gap-3 rounded-lg bg-primary/10 px-3 py-2 text-primary transition-all"
                  >
                    <Battery className="h-4 w-4" />
                    Energy Savings
                  </Link>
                  <Link
                    href="/dashboard/reports"
                    className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                  >
                    <Download className="h-4 w-4" />
                    Reports
                  </Link>
                </nav>
              </div>
            </div>
          </aside>
          <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">
                  Energy Savings
                </h1>
                <p className="text-sm text-muted-foreground">Monitor and analyze energy conservation metrics</p>
              </div>
              <div className="flex items-center gap-2">
                <Select value={timeRange} onValueChange={setTimeRange}>
                  <SelectTrigger className="w-[180px]">
                    <Calendar className="mr-2 h-4 w-4" />
                    <SelectValue placeholder="Select time range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7d">Last 7 Days</SelectItem>
                    <SelectItem value="30d">Last 30 Days</SelectItem>
                    <SelectItem value="90d">Last 90 Days</SelectItem>
                    <SelectItem value="1y">Last Year</SelectItem>
                  </SelectContent>
                </Select>
                <Button className="bg-gradient-to-r from-primary to-secondary hover:opacity-90 transition-all">
                  <Download className="mr-2 h-4 w-4" />
                  Export Data
                </Button>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              <Card className="border-2 border-primary/10 shadow-md">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Energy Saved</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Battery className="h-5 w-5 text-primary" />
                    <div className="text-2xl font-bold">{totalEnergySaved.toLocaleString()} kWh</div>
                  </div>
                  <p className="text-xs text-muted-foreground">Across all corridors</p>
                  <div className="flex items-center gap-1 mt-2">
                    <TrendingUp className="h-3 w-3 text-success" />
                    <span className="text-xs text-success">+18% from previous period</span>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-2 border-primary/10 shadow-md">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">CO₂ Reduction</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Leaf className="h-5 w-5 text-green-500" />
                    <div className="text-2xl font-bold">{totalCO2Reduction.toLocaleString()} kg</div>
                  </div>
                  <p className="text-xs text-muted-foreground">Carbon dioxide equivalent</p>
                  <div className="flex items-center gap-1 mt-2">
                    <TrendingUp className="h-3 w-3 text-success" />
                    <span className="text-xs text-success">+22% from previous period</span>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-2 border-primary/10 shadow-md">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Environmental Impact</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Lightbulb className="h-5 w-5 text-yellow-500" />
                    <div className="text-2xl font-bold">{treesEquivalent.toLocaleString()} trees</div>
                  </div>
                  <p className="text-xs text-muted-foreground">Annual absorption equivalent</p>
                  <div className="flex items-center gap-1 mt-2">
                    <TrendingUp className="h-3 w-3 text-success" />
                    <span className="text-xs text-success">Equivalent to planting a small forest</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="border-2 border-primary/10 shadow-md">
              <CardHeader>
                <CardTitle>Energy Savings</CardTitle>
                <CardDescription>Energy conservation metrics and environmental impact</CardDescription>
              </CardHeader>
              <CardContent>
                <EnergySavingsChart isLoading={false} data={energyData?.energySavings} />
              </CardContent>
            </Card>

            <div className="grid gap-4 md:grid-cols-2">
              <Card className="border-2 border-primary/10 shadow-md">
                <CardHeader>
                  <CardTitle>Energy Savings Breakdown</CardTitle>
                  <CardDescription>Distribution of energy savings by category</CardDescription>
                </CardHeader>
                <CardContent>
                  <ChartContainer className="h-[300px]">
                    <Chart className="h-full">
                      <XAxis dataKey="category" tickLine={false} axisLine={false} fontSize={12} tickMargin={12} />
                      <YAxis
                        tickLine={false}
                        axisLine={false}
                        tickFormatter={(value) => `${value}%`}
                        fontSize={12}
                        tickMargin={12}
                      />
                      <ChartTooltip
                        content={
                          <ChartTooltipContent
                            className="border-none bg-background/80 backdrop-blur-sm"
                            valueFormatter={(value) => `${value}%`}
                          />
                        }
                      />
                      <BarChart data={energyBreakdownData}>
                        <Bar dataKey="value" fill="hsl(var(--primary))" radius={4} fillOpacity={0.8} />
                      </BarChart>
                    </Chart>
                  </ChartContainer>
                </CardContent>
              </Card>

              <Card className="border-2 border-primary/10 shadow-md">
                <CardHeader>
                  <CardTitle>Monthly Energy Trends</CardTitle>
                  <CardDescription>Energy savings compared to targets</CardDescription>
                </CardHeader>
                <CardContent>
                  <ChartContainer className="h-[300px]">
                    <Chart className="h-full">
                      <XAxis dataKey="month" tickLine={false} axisLine={false} fontSize={12} tickMargin={12} />
                      <YAxis
                        tickLine={false}
                        axisLine={false}
                        tickFormatter={(value) => `${value} kWh`}
                        fontSize={12}
                        tickMargin={12}
                      />
                      <ChartTooltip
                        content={
                          <ChartTooltipContent
                            className="border-none bg-background/80 backdrop-blur-sm"
                            valueFormatter={(value) => `${value} kWh`}
                          />
                        }
                      />
                      <LineChart data={monthlyTrendData}>
                        <Line dataKey="energySaved" stroke="hsl(var(--primary))" strokeWidth={2} />
                        <Line
                          dataKey="target"
                          stroke="hsl(var(--muted-foreground))"
                          strokeWidth={2}
                          strokeDasharray="4 4"
                        />
                      </LineChart>
                    </Chart>
                  </ChartContainer>
                  <div className="flex justify-between text-xs text-muted-foreground mt-2">
                    <div className="flex items-center gap-1">
                      <div className="w-3 h-1 bg-primary"></div>
                      <span>Actual Savings</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="w-3 h-1 border-b border-dashed border-muted-foreground"></div>
                      <span>Target Savings</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="border-2 border-primary/10 shadow-md">
              <CardHeader>
                <CardTitle>Corridor Energy Savings</CardTitle>
                <CardDescription>Energy savings metrics by corridor</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col md:flex-row gap-4 mb-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search corridors..."
                        className="pl-8"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                  </div>
                </div>

                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[200px] cursor-pointer" onClick={() => handleSort("corridor")}>
                          <div className="flex items-center gap-1">
                            Corridor
                            {sortBy === "corridor" && (
                              <ArrowUpDown className={`h-4 w-4 ${sortOrder === "desc" ? "rotate-180" : ""}`} />
                            )}
                          </div>
                        </TableHead>
                        <TableHead className="cursor-pointer" onClick={() => handleSort("energySaved")}>
                          <div className="flex items-center gap-1">
                            Energy Saved
                            {sortBy === "energySaved" && (
                              <ArrowUpDown className={`h-4 w-4 ${sortOrder === "desc" ? "rotate-180" : ""}`} />
                            )}
                          </div>
                        </TableHead>
                        <TableHead>CO₂ Reduction</TableHead>
                        <TableHead className="cursor-pointer" onClick={() => handleSort("percentImprovement")}>
                          <div className="flex items-center gap-1">
                            Improvement
                            {sortBy === "percentImprovement" && (
                              <ArrowUpDown className={`h-4 w-4 ${sortOrder === "desc" ? "rotate-180" : ""}`} />
                            )}
                          </div>
                        </TableHead>
                        <TableHead>Last Updated</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredCorridors.map((corridor: any) => (
                        <TableRow key={corridor.corridor}>
                          <TableCell className="font-medium">{corridor.corridor}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Battery className="h-4 w-4 text-primary" />
                              <span>{corridor.energySaved} kWh</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Leaf className="h-4 w-4 text-green-500" />
                              <span>{corridor.co2Reduction} kg</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Badge className="bg-green-500/20 text-green-700 hover:bg-green-500/30">
                                +{corridor.percentImprovement}%
                              </Badge>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4 text-muted-foreground" />
                              <span>{corridor.lastUpdated}</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="outline" size="sm" className="mr-2">
                              View Details
                            </Button>
                            <Button variant="outline" size="sm" className="border-primary/20 hover:bg-primary/10">
                              Export
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </main>
        </div>
      </div>
    )
  }
}

