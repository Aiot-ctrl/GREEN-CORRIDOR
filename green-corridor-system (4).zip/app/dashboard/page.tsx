"use client"

import { useState } from "react"
import Link from "next/link"
import {
  Activity,
  BarChart3,
  Battery,
  Car,
  Clock,
  Download,
  Leaf,
  MapPin,
  MoreHorizontal,
  Settings,
  Zap,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DashboardOverview } from "@/components/dashboard-overview"
import { ChatbotAssistant } from "@/components/chatbot-assistant"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

export default function Dashboard() {
  const [timeRange, setTimeRange] = useState("24h")
  const [showChatbot, setShowChatbot] = useState(false)

  const handleExportReport = () => {
    // Placeholder for export report functionality
    alert("Exporting report...")
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
          <div className="flex gap-6 md:gap-10">
            <Link href="/" className="flex items-center space-x-2">
              <Leaf className="h-6 w-6 text-primary" />
              <span className="inline-block font-bold">Green Corridor System</span>
            </Link>
            <nav className="hidden gap-6 md:flex">
              <Link href="/dashboard" className="flex items-center text-sm font-medium text-primary">
                Dashboard
              </Link>
              <Link
                href="/traffic-map"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Traffic Map
              </Link>
              <Link
                href="/analytics"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Analytics
              </Link>
              <Link
                href="/settings"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Settings
              </Link>
            </nav>
          </div>
          <div className="flex flex-1 items-center justify-end space-x-4">
            <Button variant="outline" size="icon" onClick={() => setShowChatbot(!showChatbot)} className="relative">
              <Activity className="h-4 w-4" />
              <span className="sr-only">Toggle AI Assistant</span>
              {showChatbot && <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-primary"></span>}
            </Button>
            <Button variant="outline" size="icon" asChild>
              <Link href="/settings">
                <Settings className="h-4 w-4" />
                <span className="sr-only">Settings</span>
              </Link>
            </Button>
            <Button variant="outline" size="sm">
              Admin
            </Button>
          </div>
        </div>
      </header>
      <div className="grid flex-1 md:grid-cols-[240px_1fr]">
        <aside className="hidden border-r bg-muted/40 md:block">
          <div className="flex h-full max-h-screen flex-col gap-2">
            <div className="flex h-14 items-center border-b px-4">
              <Link href="/dashboard" className="flex items-center gap-2 font-semibold">
                <BarChart3 className="h-6 w-6" />
                <span>Dashboard</span>
              </Link>
            </div>
            <div className="flex-1 overflow-auto py-2">
              <nav className="grid items-start px-2 text-sm font-medium">
                <Link
                  href="/dashboard"
                  className="flex items-center gap-3 rounded-lg bg-primary/10 px-3 py-2 text-primary transition-all"
                >
                  <Activity className="h-4 w-4" />
                  Overview
                </Link>
                <Link
                  href="/dashboard/corridors"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                >
                  <MapPin className="h-4 w-4" />
                  Corridors
                </Link>
                <Link
                  href="/dashboard/vehicles"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                >
                  <Car className="h-4 w-4" />
                  Vehicles
                </Link>
                <Link
                  href="/dashboard/signals"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                >
                  <Zap className="h-4 w-4" />
                  Traffic Signals
                </Link>
                <Link
                  href="/dashboard/energy"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                >
                  <Battery className="h-4 w-4" />
                  Energy Savings
                </Link>
                <Link
                  href="/dashboard/reports"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                >
                  <Download className="h-4 w-4" />
                  Reports
                </Link>
              </nav>
            </div>
          </div>
        </aside>
        <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <h1 className="font-semibold text-lg md:text-2xl">Dashboard Overview</h1>
              <p className="text-sm text-muted-foreground">Monitor and analyze the Green Corridor System performance</p>
            </div>
            <div className="flex items-center gap-2">
              <Select value={timeRange} onValueChange={setTimeRange}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select time range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1h">Last Hour</SelectItem>
                  <SelectItem value="6h">Last 6 Hours</SelectItem>
                  <SelectItem value="24h">Last 24 Hours</SelectItem>
                  <SelectItem value="7d">Last 7 Days</SelectItem>
                  <SelectItem value="30d">Last 30 Days</SelectItem>
                </SelectContent>
              </Select>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="icon">
                    <MoreHorizontal className="h-4 w-4" />
                    <span className="sr-only">More</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                  <DropdownMenuItem>
                    <Button variant="gradient" onClick={handleExportReport}>
                      <Download className="mr-2 h-4 w-4" />
                      Export Report
                    </Button>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Clock className="mr-2 h-4 w-4" /> Schedule Report
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <Settings className="mr-2 h-4 w-4" /> Settings
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>

          <DashboardOverview />

          <div className="mt-4">
            <Card className="border-2 border-primary/10 shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle>System Health</CardTitle>
                <CardDescription>Current status of all system components</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="rounded-md border p-3 bg-gradient-to-br from-background to-muted/30">
                    <div className="text-sm font-medium text-muted-foreground">Overall Health</div>
                    <div className="text-2xl font-bold">98.2%</div>
                    <Progress value={98.2} className="h-1.5 mt-2" />
                  </div>
                  <div className="rounded-md border p-3 bg-gradient-to-br from-background to-muted/30">
                    <div className="text-sm font-medium text-muted-foreground">Signal Network</div>
                    <div className="text-2xl font-bold">99.8%</div>
                    <Progress value={99.8} className="h-1.5 mt-2" />
                  </div>
                  <div className="rounded-md border p-3 bg-gradient-to-br from-background to-muted/30">
                    <div className="text-sm font-medium text-muted-foreground">Data Processing</div>
                    <div className="text-2xl font-bold">99.9%</div>
                    <Progress value={99.9} className="h-1.5 mt-2" />
                  </div>
                  <div className="rounded-md border p-3 bg-gradient-to-br from-background to-muted/30">
                    <div className="text-sm font-medium text-muted-foreground">AI Prediction</div>
                    <div className="text-2xl font-bold">99.5%</div>
                    <Progress value={99.5} className="h-1.5 mt-2" />
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full border-primary/20 hover:bg-primary/10">
                  View System Health Dashboard
                </Button>
              </CardFooter>
            </Card>
          </div>
        </main>
      </div>
      {showChatbot && <ChatbotAssistant onClose={() => setShowChatbot(false)} />}
    </div>
  )
}

