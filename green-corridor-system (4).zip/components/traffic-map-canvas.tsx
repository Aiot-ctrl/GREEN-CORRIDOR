"use client"

import { useEffect, useRef, useState } from "react"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface TrafficMapCanvasProps {
  isLoading: boolean
  data?: any
  zoomLevel: number
  showEVs: boolean
  showAVs: boolean
  showTraditional: boolean
  showChargingStations?: boolean
}

export function TrafficMapCanvas({
  isLoading,
  data,
  zoomLevel = 1,
  showEVs = true,
  showAVs = true,
  showTraditional = true,
  showChargingStations = false,
}: TrafficMapCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [error, setError] = useState<string | null>(null)
  const [isCanvasSupported, setIsCanvasSupported] = useState(true)
  const [hoveredElement, setHoveredElement] = useState<{ type: string; data: any } | null>(null)
  const [mousePosition, setMousePosition] = useState<{ x: number; y: number } | null>(null)
  const [showTooltip, setShowTooltip] = useState(false)
  const [showHelp, setShowHelp] = useState(false)

  useEffect(() => {
    // Check if canvas is supported
    const canvas = document.createElement("canvas")
    if (!canvas.getContext) {
      setIsCanvasSupported(false)
      setError("Your browser doesn't support canvas element")
      return
    }
  }, [])

  useEffect(() => {
    if (isLoading || !data || !canvasRef.current || !isCanvasSupported) return

    try {
      const canvas = canvasRef.current
      const ctx = canvas.getContext("2d")
      if (!ctx) {
        setError("Unable to get canvas context")
        return
      }

      // Set canvas dimensions
      const resizeCanvas = () => {
        const parent = canvas.parentElement
        if (!parent) return

        // Set the canvas dimensions to match the parent container
        canvas.width = parent.clientWidth
        canvas.height = parent.clientHeight

        renderMap()
      }

      // Initial resize
      resizeCanvas()

      // Add resize listener
      window.addEventListener("resize", resizeCanvas)

      // Handle mouse move for interactive elements
      const handleMouseMove = (e: MouseEvent) => {
        const rect = canvas.getBoundingClientRect()
        const x = (e.clientX - rect.left) / zoomLevel
        const y = (e.clientY - rect.top) / zoomLevel

        setMousePosition({ x, y })

        // Check if mouse is over a vehicle or signal
        let found = false

        // Check vehicles
        if (data.vehicles) {
          for (const vehicle of data.vehicles) {
            if (!vehicle || typeof vehicle.x !== "number" || typeof vehicle.y !== "number") continue

            const dx = x - vehicle.x
            const dy = y - vehicle.y
            const distance = Math.sqrt(dx * dx + dy * dy)

            if (distance < 10) {
              // 10px hit area
              setHoveredElement({
                type: "vehicle",
                data: vehicle,
              })
              setShowTooltip(true)
              found = true
              break
            }
          }
        }

        // Check signals if no vehicle was found
        if (!found && data.signals) {
          for (const signal of data.signals) {
            if (!signal || typeof signal.x !== "number" || typeof signal.y !== "number") continue

            const dx = x - signal.x
            const dy = y - signal.y
            const distance = Math.sqrt(dx * dx + dy * dy)

            if (distance < 12) {
              // 12px hit area
              setHoveredElement({
                type: "signal",
                data: signal,
              })
              setShowTooltip(true)
              found = true
              break
            }
          }
        }

        // Check roads if no vehicle or signal was found
        if (!found && data.roads) {
          for (const road of data.roads) {
            if (!road || !road.start || !road.end) continue

            // Simple line-point distance calculation
            const x1 = road.start.x
            const y1 = road.start.y
            const x2 = road.end.x
            const y2 = road.end.y

            if (typeof x1 !== "number" || typeof y1 !== "number" || typeof x2 !== "number" || typeof y2 !== "number")
              continue

            const A = x - x1
            const B = y - y1
            const C = x2 - x1
            const D = y2 - y1

            const dot = A * C + B * D
            const len_sq = C * C + D * D
            let param = -1

            if (len_sq !== 0) param = dot / len_sq

            let xx, yy

            if (param < 0) {
              xx = x1
              yy = y1
            } else if (param > 1) {
              xx = x2
              yy = y2
            } else {
              xx = x1 + param * C
              yy = y1 + param * D
            }

            const dx = x - xx
            const dy = y - yy
            const distance = Math.sqrt(dx * dx + dy * dy)
            const roadWidth = road.width || 10

            if (distance < roadWidth / 2 + 5) {
              // Road width plus some margin
              setHoveredElement({
                type: "road",
                data: road,
              })
              setShowTooltip(true)
              found = true
              break
            }
          }
        }

        if (!found) {
          setHoveredElement(null)
          setShowTooltip(false)
        }
      }

      canvas.addEventListener("mousemove", handleMouseMove)

      // Render map function
      function renderMap() {
        if (!ctx) return

        // Clear canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height)

        // Apply zoom
        ctx.save()
        ctx.scale(zoomLevel, zoomLevel)

        // Draw map background with gradient
        const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height)
        gradient.addColorStop(0, "#f0fdf4") // Light green tint
        gradient.addColorStop(1, "#e6f0f8")
        ctx.fillStyle = gradient
        ctx.fillRect(0, 0, canvas.width / zoomLevel, canvas.height / zoomLevel)

        // Draw grid lines for reference
        drawGrid(ctx, canvas.width / zoomLevel, canvas.height / zoomLevel)

        // Draw roads
        if (data.roads && Array.isArray(data.roads)) {
          drawRoads()
        }

        // Draw traffic signals
        if (data.signals && Array.isArray(data.signals)) {
          drawTrafficSignals()
        }

        // Draw vehicles
        if (data.vehicles && Array.isArray(data.vehicles)) {
          drawVehicles()
        }

        // Draw charging stations if enabled
        if (showChargingStations && data.chargingStations && Array.isArray(data.chargingStations)) {
          drawChargingStations()
        }

        // Restore context
        ctx.restore()
      }

      function drawGrid(ctx: CanvasRenderingContext2D, width: number, height: number) {
        ctx.beginPath()
        ctx.strokeStyle = "#e9ecef"
        ctx.lineWidth = 0.5

        // Draw vertical lines
        for (let x = 0; x <= width; x += 50) {
          ctx.moveTo(x, 0)
          ctx.lineTo(x, height)
        }

        // Draw horizontal lines
        for (let y = 0; y <= height; y += 50) {
          ctx.moveTo(0, y)
          ctx.lineTo(width, y)
        }

        ctx.stroke()
      }

      function drawRoads() {
        if (!ctx || !data.roads) return

        data.roads.forEach((road: any) => {
          if (!road || !road.start || !road.end) return

          // Draw road background
          ctx.beginPath()
          ctx.moveTo(road.start.x, road.start.y)
          ctx.lineTo(road.end.x, road.end.y)
          ctx.strokeStyle = "#333"
          ctx.lineWidth = road.width || 10
          ctx.stroke()

          // Add road markings
          drawRoadMarkings(road)

          // Highlight hovered road
          if (hoveredElement?.type === "road" && hoveredElement.data === road) {
            ctx.beginPath()
            ctx.moveTo(road.start.x, road.start.y)
            ctx.lineTo(road.end.x, road.end.y)
            ctx.strokeStyle = "rgba(34, 197, 94, 0.5)" // Green highlight
            ctx.lineWidth = (road.width || 10) + 4
            ctx.stroke()
          }

          // Draw road name
          if (road.name) {
            const midX = (road.start.x + road.end.x) / 2
            const midY = (road.start.y + road.end.y) / 2

            ctx.save()
            ctx.fillStyle = "rgba(255, 255, 255, 0.9)"
            ctx.strokeStyle = "rgba(0, 0, 0, 0.3)"
            ctx.lineWidth = 2

            // Draw text background
            const textWidth = ctx.measureText(road.name).width
            const padding = 5
            ctx.beginPath()
            ctx.roundRect(midX - textWidth / 2 - padding, midY - 8, textWidth + padding * 2, 16, 4)
            ctx.fill()
            ctx.stroke()

            // Draw text
            ctx.fillStyle = "#333"
            ctx.font = "12px sans-serif"
            ctx.textAlign = "center"
            ctx.textBaseline = "middle"
            ctx.fillText(road.name, midX, midY)
            ctx.restore()
          }
        })
      }

      function drawRoadMarkings(road: any) {
        if (!ctx || !road || !road.start || !road.end) return

        const dx = road.end.x - road.start.x
        const dy = road.end.y - road.start.y
        const length = Math.sqrt(dx * dx + dy * dy)
        const angle = Math.atan2(dy, dx)

        // Draw dashed line in the middle of the road
        ctx.save()
        ctx.strokeStyle = "#fff"
        ctx.lineWidth = 1
        ctx.setLineDash([10, 10])

        ctx.beginPath()
        ctx.moveTo(road.start.x, road.start.y)
        ctx.lineTo(road.end.x, road.end.y)
        ctx.stroke()

        // Draw solid lines on the edges for major roads
        if (road.width >= 12) {
          ctx.setLineDash([])
          ctx.strokeStyle = "#fff"
          ctx.lineWidth = 1

          // Calculate perpendicular offset
          const perpX = (-dy / length) * (road.width / 2 - 1)
          const perpY = (dx / length) * (road.width / 2 - 1)

          // Draw left edge
          ctx.beginPath()
          ctx.moveTo(road.start.x + perpX, road.start.y + perpY)
          ctx.lineTo(road.end.x + perpX, road.end.y + perpY)
          ctx.stroke()

          // Draw right edge
          ctx.beginPath()
          ctx.moveTo(road.start.x - perpX, road.start.y - perpY)
          ctx.lineTo(road.end.x - perpX, road.end.y - perpY)
          ctx.stroke()
        }

        ctx.setLineDash([])
        ctx.restore()
      }

      function drawTrafficSignals() {
        if (!ctx || !data.signals) return

        data.signals.forEach((signal: any) => {
          if (!signal || typeof signal.x !== "number" || typeof signal.y !== "number") return

          // Draw signal base
          ctx.beginPath()
          ctx.arc(signal.x, signal.y, 8, 0, Math.PI * 2)
          ctx.fillStyle = "#333"
          ctx.fill()

          // Draw signal light
          ctx.beginPath()
          ctx.arc(signal.x, signal.y, 5, 0, Math.PI * 2)

          // Set color based on signal status
          switch (signal.status) {
            case "green":
              ctx.fillStyle = "#22c55e" // Green
              break
            case "yellow":
              ctx.fillStyle = "#facc15" // Yellow
              break
            case "red":
              ctx.fillStyle = "#ef4444" // Red
              break
            default:
              ctx.fillStyle = "#a3a3a3" // Gray
          }

          ctx.fill()

          // Add glow effect for active signals
          ctx.beginPath()
          ctx.arc(signal.x, signal.y, 5, 0, Math.PI * 2)
          ctx.strokeStyle =
            signal.status === "green"
              ? "rgba(34, 197, 94, 0.5)"
              : signal.status === "yellow"
                ? "rgba(250, 204, 21, 0.5)"
                : "rgba(239, 68, 68, 0.5)"
          ctx.lineWidth = 3
          ctx.stroke()

          // Draw signal efficiency indicator
          if (signal.efficiency !== undefined) {
            ctx.beginPath()
            ctx.arc(signal.x, signal.y, 12, 0, Math.PI * 2)
            ctx.strokeStyle = signal.efficiency > 80 ? "#22c55e" : signal.efficiency > 50 ? "#facc15" : "#ef4444"
            ctx.lineWidth = 2
            ctx.stroke()
          }

          // Highlight hovered signal
          if (hoveredElement?.type === "signal" && hoveredElement.data === signal) {
            ctx.beginPath()
            ctx.arc(signal.x, signal.y, 15, 0, Math.PI * 2)
            ctx.strokeStyle = "rgba(34, 197, 94, 0.5)" // Green highlight
            ctx.lineWidth = 2
            ctx.stroke()
          }
        })
      }

      function drawVehicles() {
        if (!ctx || !data.vehicles) return

        data.vehicles.forEach((vehicle: any) => {
          if (!vehicle || typeof vehicle.x !== "number" || typeof vehicle.y !== "number") return

          // Skip based on filter settings
          if (vehicle.type === "ev" && !showEVs) return
          if (vehicle.type === "av" && !showAVs) return
          if (vehicle.type === "traditional" && !showTraditional) return

          ctx.save()

          // Translate to vehicle position
          ctx.translate(vehicle.x, vehicle.y)

          // Rotate to vehicle direction
          if (vehicle.direction !== undefined) {
            ctx.rotate(vehicle.direction)
          }

          // Draw vehicle
          ctx.beginPath()

          // Different shapes for different vehicle types
          if (vehicle.type === "ev") {
            // Electric vehicle (rectangle with rounded corners)
            ctx.fillStyle = "#3b82f6" // Blue
            roundedRect(ctx, -8, -4, 16, 8, 2)

            // Add EV indicator
            ctx.fillStyle = "#fff"
            ctx.beginPath()
            ctx.arc(0, 0, 2, 0, Math.PI * 2)
            ctx.fill()

            // Add lightning bolt icon for EV
            ctx.beginPath()
            ctx.moveTo(-1, -2)
            ctx.lineTo(1, -2)
            ctx.lineTo(0, 0)
            ctx.lineTo(2, 0)
            ctx.lineTo(-1, 3)
            ctx.lineTo(0, 0)
            ctx.lineTo(-2, 0)
            ctx.closePath()
            ctx.fillStyle = "#fff"
            ctx.fill()
          } else if (vehicle.type === "av") {
            // Autonomous vehicle (circle)
            ctx.fillStyle = "#8b5cf6" // Purple
            ctx.arc(0, 0, 6, 0, Math.PI * 2)

            // Add AV indicator (concentric circles)
            ctx.fill()
            ctx.strokeStyle = "#fff"
            ctx.lineWidth = 1
            ctx.beginPath()
            ctx.arc(0, 0, 3, 0, Math.PI * 2)
            ctx.stroke()

            // Add radar-like lines
            ctx.beginPath()
            ctx.moveTo(-4, 0)
            ctx.lineTo(4, 0)
            ctx.moveTo(0, -4)
            ctx.lineTo(0, 4)
            ctx.strokeStyle = "rgba(255, 255, 255, 0.5)"
            ctx.stroke()
          } else {
            // Traditional vehicle (rectangle)
            ctx.fillStyle = "#6b7280" // Gray
            ctx.rect(-7, -3, 14, 6)
            ctx.fill()
          }

          // Add shadow for depth
          ctx.shadowColor = "rgba(0, 0, 0, 0.2)"
          ctx.shadowBlur = 2
          ctx.shadowOffsetX = 1
          ctx.shadowOffsetY = 1

          // Highlight hovered vehicle
          if (hoveredElement?.type === "vehicle" && hoveredElement.data === vehicle) {
            ctx.beginPath()
            ctx.arc(0, 0, 10, 0, Math.PI * 2)
            ctx.strokeStyle = "rgba(34, 197, 94, 0.5)" // Green highlight
            ctx.lineWidth = 2
            ctx.stroke()
          }

          ctx.restore()
        })
      }

      // Add function to draw charging stations
      function drawChargingStations() {
        if (!ctx || !data.chargingStations) return

        // If charging stations data doesn't exist in the map data, create some sample stations
        const stations =
          data.chargingStations.length > 0
            ? data.chargingStations
            : [
                { x: 150, y: 150, status: "available", name: "Downtown Charger" },
                { x: 300, y: 250, status: "busy", name: "Central Station" },
                { x: 450, y: 150, status: "available", name: "North Charger" },
                { x: 200, y: 350, status: "maintenance", name: "West Charger" },
              ]

        stations.forEach((station: any) => {
          if (!station || typeof station.x !== "number" || typeof station.y !== "number") return

          // Draw station base
          ctx.beginPath()
          ctx.arc(station.x, station.y, 10, 0, Math.PI * 2)
          ctx.fillStyle = station.status === "available" ? "#22c55e" : station.status === "busy" ? "#facc15" : "#a3a3a3"
          ctx.fill()

          // Draw charging icon
          ctx.beginPath()
          ctx.moveTo(station.x - 3, station.y - 2)
          ctx.lineTo(station.x + 1, station.y - 2)
          ctx.lineTo(station.x - 1, station.y + 2)
          ctx.lineTo(station.x + 3, station.y + 2)
          ctx.strokeStyle = "#fff"
          ctx.lineWidth = 1.5
          ctx.stroke()

          // Add glow effect for available stations
          if (station.status === "available") {
            ctx.beginPath()
            ctx.arc(station.x, station.y, 12, 0, Math.PI * 2)
            ctx.strokeStyle = "rgba(34, 197, 94, 0.5)"
            ctx.lineWidth = 2
            ctx.stroke()
          }

          // Highlight hovered station
          if (hoveredElement?.type === "chargingStation" && hoveredElement.data === station) {
            ctx.beginPath()
            ctx.arc(station.x, station.y, 15, 0, Math.PI * 2)
            ctx.strokeStyle = "rgba(34, 197, 94, 0.5)"
            ctx.lineWidth = 2
            ctx.stroke()
          }
        })
      }

      // Helper function for rounded rectangles
      function roundedRect(
        ctx: CanvasRenderingContext2D,
        x: number,
        y: number,
        width: number,
        height: number,
        radius: number,
      ) {
        ctx.beginPath()
        ctx.moveTo(x + radius, y)
        ctx.lineTo(x + width - radius, y)
        ctx.quadraticCurveTo(x + width, y, x + width, y + radius)
        ctx.lineTo(x + width, y + height - radius)
        ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height)
        ctx.lineTo(x + radius, y + height)
        ctx.quadraticCurveTo(x, y + height, x, y + height - radius)
        ctx.lineTo(x, y + radius)
        ctx.quadraticCurveTo(x, y, x + radius, y)
        ctx.closePath()
      }

      // Initial render
      renderMap()

      // Animation loop for moving vehicles
      let animationFrameId: number

      const animate = () => {
        if (!data.vehicles) return

        // Update vehicle positions
        data.vehicles.forEach((vehicle: any) => {
          if (!vehicle || typeof vehicle.x !== "number" || typeof vehicle.y !== "number") return

          // Simple movement logic
          const speed = vehicle.speed || 1
          const angle = vehicle.direction || 0

          vehicle.x += Math.cos(angle) * speed
          vehicle.y += Math.sin(angle) * speed

          // Wrap around the canvas
          if (vehicle.x > canvas.width / zoomLevel) vehicle.x = 0
          if (vehicle.x < 0) vehicle.x = canvas.width / zoomLevel
          if (vehicle.y > canvas.height / zoomLevel) vehicle.y = 0
          if (vehicle.y < 0) vehicle.y = canvas.height / zoomLevel
        })

        renderMap()
        animationFrameId = requestAnimationFrame(animate)
      }

      animate()

      // Cleanup
      return () => {
        window.removeEventListener("resize", resizeCanvas)
        canvas.removeEventListener("mousemove", handleMouseMove)
        cancelAnimationFrame(animationFrameId)
      }
    } catch (err) {
      console.error("Error rendering traffic map:", err)
      setError(err instanceof Error ? err.message : "An error occurred rendering the map")
    }
  }, [
    isLoading,
    data,
    zoomLevel,
    showEVs,
    showAVs,
    showTraditional,
    showChargingStations,
    isCanvasSupported,
    hoveredElement,
  ])

  if (!isCanvasSupported) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>
          Your browser doesn't support the canvas element required for the traffic map.
        </AlertDescription>
      </Alert>
    )
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    )
  }

  if (isLoading) {
    return (
      <div className="relative h-full w-full bg-muted/20 rounded-lg flex items-center justify-center">
        <Skeleton className="h-full w-full absolute" />
        <div className="text-center z-10">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
          <p className="mt-2 text-sm text-muted-foreground">Loading map data...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="relative h-full w-full">
      <canvas ref={canvasRef} className="w-full h-full rounded-lg" />

      {/* Help button */}
      <div className="absolute top-4 left-4 z-10">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                className="bg-background/80 backdrop-blur-sm"
                onClick={() => setShowHelp(!showHelp)}
              >
                <Info className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Map Help</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      {/* Help panel */}
      {showHelp && (
        <div className="absolute top-14 left-4 z-10 bg-background/90 backdrop-blur-sm p-4 rounded-lg border shadow-lg max-w-xs">
          <h4 className="font-medium mb-2">Traffic Map Help</h4>
          <ul className="text-sm space-y-2">
            <li>• Hover over elements to see details</li>
            <li>• Use zoom controls to adjust view</li>
            <li>• Toggle vehicle types using filters</li>
            <li>
              • <span className="inline-block w-3 h-3 bg-[#3b82f6] rounded-sm align-middle mr-1"></span> Blue: Electric
              Vehicles
            </li>
            <li>
              • <span className="inline-block w-3 h-3 bg-[#8b5cf6] rounded-full align-middle mr-1"></span> Purple:
              Autonomous Vehicles
            </li>
            <li>
              • <span className="inline-block w-3 h-3 bg-[#6b7280] rounded-sm align-middle mr-1"></span> Gray:
              Traditional Vehicles
            </li>
          </ul>
          <Button variant="outline" size="sm" className="mt-3 w-full" onClick={() => setShowHelp(false)}>
            Close
          </Button>
        </div>
      )}

      {/* Tooltip for hovered elements */}
      {showTooltip && hoveredElement && mousePosition && (
        <div
          className="absolute z-20 bg-background/90 backdrop-blur-sm p-2 rounded-lg border shadow-md text-xs"
          style={{
            left: mousePosition.x * zoomLevel + 15,
            top: mousePosition.y * zoomLevel + 15,
            maxWidth: "200px",
          }}
        >
          {hoveredElement.type === "vehicle" && (
            <>
              <div className="font-medium">
                {hoveredElement.data.type === "ev"
                  ? "Electric Vehicle"
                  : hoveredElement.data.type === "av"
                    ? "Autonomous Vehicle"
                    : "Traditional Vehicle"}
              </div>
              <div className="text-muted-foreground mt-1">Speed: {hoveredElement.data.speed} units/s</div>
            </>
          )}

          {hoveredElement.type === "signal" && (
            <>
              <div className="font-medium">Traffic Signal</div>
              <div className="text-muted-foreground mt-1">
                Status:{" "}
                <span
                  className={
                    hoveredElement.data.status === "green"
                      ? "text-green-500"
                      : hoveredElement.data.status === "yellow"
                        ? "text-yellow-500"
                        : "text-red-500"
                  }
                >
                  {hoveredElement.data.status.charAt(0).toUpperCase() + hoveredElement.data.status.slice(1)}
                </span>
              </div>
              {hoveredElement.data.efficiency !== undefined && (
                <div className="text-muted-foreground">Efficiency: {hoveredElement.data.efficiency}%</div>
              )}
            </>
          )}

          {hoveredElement.type === "road" && (
            <>
              <div className="font-medium">{hoveredElement.data.name}</div>
              <div className="text-muted-foreground mt-1">Width: {hoveredElement.data.width} units</div>
            </>
          )}
          {hoveredElement.type === "chargingStation" && (
            <>
              <div className="font-medium">Charging Station</div>
              <div className="text-muted-foreground mt-1">Name: {hoveredElement.data.name}</div>
              <div className="text-muted-foreground">Status: {hoveredElement.data.status}</div>
            </>
          )}
        </div>
      )}

      {!data && (
        <div className="absolute inset-0 flex items-center justify-center">
          <p className="text-muted-foreground">No map data available</p>
        </div>
      )}
    </div>
  )
}

