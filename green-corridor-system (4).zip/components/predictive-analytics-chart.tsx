"use client"

import { Skeleton } from "@/components/ui/skeleton"
import {
  Chart,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  Line,
  LineChart,
  XAxis,
  YAxis,
  LinearGradient,
  LinearGradientStop,
} from "@/components/ui/chart"

interface PredictiveAnalyticsChartProps {
  isLoading: boolean
  data?: {
    date: string
    actual: number
    predicted: number
    lowerBound?: number
    upperBound?: number
  }[]
}

export function PredictiveAnalyticsChart({ isLoading, data }: PredictiveAnalyticsChartProps) {
  if (isLoading || !data) {
    return <Skeleton className="h-[400px] w-full" />
  }

  return (
    <ChartContainer className="h-[400px]">
      <Chart className="h-full">
        <LinearGradient id="predictiveGradient" direction="bottom">
          <LinearGradientStop offset="0%" color="hsl(var(--primary))" opacity={0.2} />
          <LinearGradientStop offset="100%" color="hsl(var(--primary))" opacity={0} />
        </LinearGradient>
        <XAxis dataKey="date" tickLine={false} axisLine={false} fontSize={12} tickMargin={12} />
        <YAxis tickLine={false} axisLine={false} tickFormatter={(value) => `${value}`} fontSize={12} tickMargin={12} />
        <ChartTooltip
          content={
            <ChartTooltipContent
              className="border-none bg-background/80 backdrop-blur-sm"
              valueFormatter={(value) => `${value} vehicles`}
            />
          }
        />
        <LineChart data={data}>
          <Line dataKey="actual" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ fill: "hsl(var(--primary))" }} />
          <Line
            dataKey="predicted"
            stroke="hsl(var(--primary)/0.5)"
            strokeWidth={2}
            strokeDasharray="4 4"
            dot={{ fill: "hsl(var(--primary)/0.5)" }}
          />
          <Line dataKey="upperBound" stroke="hsl(var(--muted-foreground)/0.3)" strokeWidth={1} dot={false} />
          <Line dataKey="lowerBound" stroke="hsl(var(--muted-foreground)/0.3)" strokeWidth={1} dot={false} />
        </LineChart>
      </Chart>
    </ChartContainer>
  )
}

