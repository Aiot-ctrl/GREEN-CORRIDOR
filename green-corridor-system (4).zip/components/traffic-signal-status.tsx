"use client"

import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface TrafficSignalStatusProps {
  isLoading: boolean
  data?: {
    id: string
    location: string
    status: "operational" | "warning" | "error" | "maintenance"
    lastUpdated: string
    efficiency: number
  }[]
}

export function TrafficSignalStatus({ isLoading, data }: TrafficSignalStatusProps) {
  if (isLoading || !data) {
    return <Skeleton className="h-[400px] w-full" />
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "operational":
        return <Badge className="bg-green-500">Operational</Badge>
      case "warning":
        return <Badge className="bg-yellow-500">Warning</Badge>
      case "error":
        return <Badge className="bg-red-500">Error</Badge>
      case "maintenance":
        return <Badge className="bg-blue-500">Maintenance</Badge>
      default:
        return <Badge>Unknown</Badge>
    }
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Signal ID</TableHead>
            <TableHead>Location</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Last Updated</TableHead>
            <TableHead className="text-right">Efficiency</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((signal) => (
            <TableRow key={signal.id}>
              <TableCell className="font-medium">{signal.id}</TableCell>
              <TableCell>{signal.location}</TableCell>
              <TableCell>{getStatusBadge(signal.status)}</TableCell>
              <TableCell>{signal.lastUpdated}</TableCell>
              <TableCell className="text-right">{signal.efficiency}%</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

