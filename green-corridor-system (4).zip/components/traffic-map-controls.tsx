"use client"

import { useState } from "react"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"

export function TrafficMapControls() {
  const [showTrafficDensity, setShowTrafficDensity] = useState(true)
  const [showSignals, setShowSignals] = useState(true)
  const [showCorridors, setShowCorridors] = useState(true)
  const [showPredictions, setShowPredictions] = useState(false)
  const [showHeatmap, setShowHeatmap] = useState(false)

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <Label htmlFor="show-traffic-density">Traffic Density</Label>
        <Switch id="show-traffic-density" checked={showTrafficDensity} onCheckedChange={setShowTrafficDensity} />
      </div>
      <div className="flex items-center justify-between">
        <Label htmlFor="show-signals">Traffic Signals</Label>
        <Switch id="show-signals" checked={showSignals} onCheckedChange={setShowSignals} />
      </div>
      <div className="flex items-center justify-between">
        <Label htmlFor="show-corridors">Green Corridors</Label>
        <Switch id="show-corridors" checked={showCorridors} onCheckedChange={setShowCorridors} />
      </div>
      <div className="flex items-center justify-between">
        <Label htmlFor="show-predictions">Traffic Predictions</Label>
        <Switch id="show-predictions" checked={showPredictions} onCheckedChange={setShowPredictions} />
      </div>
      <div className="flex items-center justify-between">
        <Label htmlFor="show-heatmap">Energy Efficiency Heatmap</Label>
        <Switch id="show-heatmap" checked={showHeatmap} onCheckedChange={setShowHeatmap} />
      </div>
    </div>
  )
}

