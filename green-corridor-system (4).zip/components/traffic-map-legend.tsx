export function TrafficMapLegend() {
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <h3 className="text-sm font-medium">Vehicle Types</h3>
        <div className="grid grid-cols-1 gap-2">
          <div className="flex items-center gap-2">
            <div className="h-4 w-8 rounded-sm bg-[#3b82f6]"></div>
            <span className="text-sm">Electric Vehicles</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-4 w-8 rounded-sm bg-[#8b5cf6]"></div>
            <span className="text-sm">Autonomous Vehicles</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-4 w-8 rounded-sm bg-[#6b7280]"></div>
            <span className="text-sm">Traditional Vehicles</span>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <h3 className="text-sm font-medium">Traffic Signals</h3>
        <div className="grid grid-cols-1 gap-2">
          <div className="flex items-center gap-2">
            <div className="h-4 w-4 rounded-full bg-[#4ade80]"></div>
            <span className="text-sm">Green (Optimal Flow)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-4 w-4 rounded-full bg-[#facc15]"></div>
            <span className="text-sm">Yellow (Moderate Flow)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-4 w-4 rounded-full bg-[#f87171]"></div>
            <span className="text-sm">Red (Congested)</span>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <h3 className="text-sm font-medium">Traffic Density</h3>
        <div className="grid grid-cols-1 gap-2">
          <div className="flex items-center gap-2">
            <div className="h-4 w-8 rounded-sm bg-gradient-to-r from-green-500 to-green-300"></div>
            <span className="text-sm">Low Density</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-4 w-8 rounded-sm bg-gradient-to-r from-yellow-500 to-yellow-300"></div>
            <span className="text-sm">Medium Density</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-4 w-8 rounded-sm bg-gradient-to-r from-red-500 to-red-300"></div>
            <span className="text-sm">High Density</span>
          </div>
        </div>
      </div>
    </div>
  )
}

