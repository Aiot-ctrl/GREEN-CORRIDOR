"use client"

import { useState, useEffect } from "react"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, BatteryCharging, Zap, Info, MapPin, Car, Search, Filter, Compass } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"

interface ChargingStation {
  id: string
  name: string
  location: string
  coordinates: { lat: number; lng: number }
  status: "available" | "busy" | "maintenance"
  chargerTypes: string[]
  chargingSpeed: number
  pricePerKwh: number
  amenities: string[]
  waitTime?: number
  distance?: number
  capacity?: number
  available?: number
  rating?: number
}

interface EVChargingStationsProps {
  isLoading?: boolean
  currentLocation?: { lat: number; lng: number }
  route?: { start: string; end: string }
}

export function EVChargingStations({ isLoading = false, currentLocation, route }: EVChargingStationsProps) {
  const [stations, setStations] = useState<ChargingStation[]>([])
  const [filteredStations, setFilteredStations] = useState<ChargingStation[]>([])
  const [error, setError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<string>("map")
  const [mapView, setMapView] = useState<"standard" | "satellite">("standard")
  const [selectedStation, setSelectedStation] = useState<ChargingStation | null>(null)
  const [showDetails, setShowDetails] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [filterStatus, setFilterStatus] = useState<string>("all")
  const [filterDistance, setFilterDistance] = useState<number[]>([10])
  const [filterChargingSpeed, setFilterChargingSpeed] = useState<string>("all")
  const [showOnlyAvailable, setShowOnlyAvailable] = useState(true)
  const [isFiltersOpen, setIsFiltersOpen] = useState(false)

  useEffect(() => {
    if (!isLoading) {
      try {
        // Simulate fetching charging station data
        const mockStations: ChargingStation[] = [
          {
            id: "cs-001",
            name: "GreenCharge Downtown",
            location: "123 Main St, Downtown",
            coordinates: { lat: 40.7128, lng: -74.006 },
            status: "available",
            chargerTypes: ["Level 2", "DC Fast Charging"],
            chargingSpeed: 150,
            pricePerKwh: 0.35,
            amenities: ["Restrooms", "Coffee Shop", "WiFi"],
            waitTime: 0,
            distance: 0.5,
            capacity: 6,
            available: 4,
            rating: 4.8,
          },
          {
            id: "cs-002",
            name: "EcoStation University",
            location: "456 College Ave, University District",
            coordinates: { lat: 40.7282, lng: -73.994 },
            status: "busy",
            chargerTypes: ["Level 2", "DC Fast Charging", "Tesla Supercharger"],
            chargingSpeed: 250,
            pricePerKwh: 0.4,
            amenities: ["Restrooms", "Restaurant", "Shopping", "WiFi"],
            waitTime: 15,
            distance: 1.2,
            capacity: 8,
            available: 1,
            rating: 4.5,
          },
          {
            id: "cs-003",
            name: "PowerUp Industrial",
            location: "789 Factory Rd, Industrial Zone",
            coordinates: { lat: 40.7023, lng: -74.012 },
            status: "available",
            chargerTypes: ["Level 2", "DC Fast Charging"],
            chargingSpeed: 100,
            pricePerKwh: 0.3,
            amenities: ["Restrooms", "Vending Machines"],
            waitTime: 0,
            distance: 2.3,
            capacity: 4,
            available: 3,
            rating: 4.2,
          },
          {
            id: "cs-004",
            name: "QuickCharge Mall",
            location: "321 Shopping Blvd, Retail District",
            coordinates: { lat: 40.7192, lng: -73.986 },
            status: "busy",
            chargerTypes: ["Level 2", "DC Fast Charging"],
            chargingSpeed: 200,
            pricePerKwh: 0.38,
            amenities: ["Restrooms", "Food Court", "Shopping", "WiFi"],
            waitTime: 10,
            distance: 1.8,
            capacity: 10,
            available: 2,
            rating: 4.7,
          },
          {
            id: "cs-005",
            name: "EV Oasis Highway",
            location: "555 Interstate Pkwy, Highway Exit 12",
            coordinates: { lat: 40.6892, lng: -74.045 },
            status: "maintenance",
            chargerTypes: ["Level 2", "DC Fast Charging", "Tesla Supercharger"],
            chargingSpeed: 300,
            pricePerKwh: 0.42,
            amenities: ["Restrooms", "Convenience Store", "Restaurant", "WiFi"],
            waitTime: null,
            distance: 5.2,
            capacity: 12,
            available: 0,
            rating: 4.9,
          },
          {
            id: "cs-006",
            name: "Green Energy Plaza",
            location: "789 Eco Blvd, Green District",
            coordinates: { lat: 40.7328, lng: -74.026 },
            status: "available",
            chargerTypes: ["Level 2", "DC Fast Charging", "Wireless Charging"],
            chargingSpeed: 180,
            pricePerKwh: 0.36,
            amenities: ["Restrooms", "Cafe", "WiFi", "Lounge"],
            waitTime: 0,
            distance: 3.1,
            capacity: 8,
            available: 5,
            rating: 4.6,
          },
          {
            id: "cs-007",
            name: "City Center Charging",
            location: "101 Central Ave, Downtown",
            coordinates: { lat: 40.7148, lng: -74.016 },
            status: "busy",
            chargerTypes: ["Level 2", "DC Fast Charging"],
            chargingSpeed: 120,
            pricePerKwh: 0.33,
            amenities: ["Restrooms", "WiFi"],
            waitTime: 5,
            distance: 0.8,
            capacity: 4,
            available: 1,
            rating: 4.3,
          },
          {
            id: "cs-008",
            name: "Riverside Chargers",
            location: "222 River Rd, Waterfront",
            coordinates: { lat: 40.7028, lng: -74.032 },
            status: "available",
            chargerTypes: ["Level 2", "DC Fast Charging"],
            chargingSpeed: 160,
            pricePerKwh: 0.37,
            amenities: ["Restrooms", "Park", "WiFi", "Picnic Area"],
            waitTime: 0,
            distance: 2.7,
            capacity: 6,
            available: 4,
            rating: 4.4,
          },
        ]

        setStations(mockStations)
        setFilteredStations(mockStations)
      } catch (err) {
        console.error("Error loading charging station data:", err)
        setError("Failed to load charging station data")
      }
    }
  }, [isLoading])

  // Apply filters when any filter changes
  useEffect(() => {
    if (stations.length === 0) return

    let filtered = [...stations]

    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (station) => station.name.toLowerCase().includes(query) || station.location.toLowerCase().includes(query),
      )
    }

    // Apply status filter
    if (filterStatus !== "all") {
      filtered = filtered.filter((station) => station.status === filterStatus)
    }

    // Apply availability filter
    if (showOnlyAvailable) {
      filtered = filtered.filter(
        (station) => station.status === "available" && station.available !== undefined && station.available > 0,
      )
    }

    // Apply distance filter
    filtered = filtered.filter((station) => station.distance !== undefined && station.distance <= filterDistance[0])

    // Apply charging speed filter
    if (filterChargingSpeed !== "all") {
      const speedMap: Record<string, number[]> = {
        standard: [0, 100],
        fast: [100, 200],
        ultra: [200, 1000],
      }

      const [min, max] = speedMap[filterChargingSpeed]
      filtered = filtered.filter((station) => station.chargingSpeed >= min && station.chargingSpeed <= max)
    }

    setFilteredStations(filtered)
  }, [stations, searchQuery, filterStatus, filterDistance, filterChargingSpeed, showOnlyAvailable])

  const handleStationClick = (station: ChargingStation) => {
    setSelectedStation(station)
    setShowDetails(true)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-success text-success-foreground"
      case "busy":
        return "bg-warning text-warning-foreground"
      case "maintenance":
        return "bg-destructive text-destructive-foreground"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "available":
        return "Available"
      case "busy":
        return "Busy"
      case "maintenance":
        return "Maintenance"
      default:
        return "Unknown"
    }
  }

  const getChargingSpeedText = (speed: number) => {
    if (speed >= 200) return "Ultra Fast"
    if (speed >= 100) return "Fast"
    return "Standard"
  }

  if (isLoading) {
    return <Skeleton className="h-[500px] w-full" />
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold">EV Charging Stations</h2>
          <p className="text-sm text-muted-foreground">Find charging stations along your route</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant={mapView === "standard" ? "default" : "outline"}
            size="sm"
            onClick={() => setMapView("standard")}
            className={mapView === "standard" ? "bg-primary" : ""}
          >
            Standard
          </Button>
          <Button
            variant={mapView === "satellite" ? "default" : "outline"}
            size="sm"
            onClick={() => setMapView("satellite")}
            className={mapView === "satellite" ? "bg-primary" : ""}
          >
            Satellite
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="bg-muted/50 p-1">
          <TabsTrigger
            value="map"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary/80 data-[state=active]:to-secondary/80 data-[state=active]:text-white"
          >
            Map View
          </TabsTrigger>
          <TabsTrigger
            value="list"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary/80 data-[state=active]:to-secondary/80 data-[state=active]:text-white"
          >
            List View
          </TabsTrigger>
          <TabsTrigger
            value="route"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary/80 data-[state=active]:to-secondary/80 data-[state=active]:text-white"
          >
            Route Planning
          </TabsTrigger>
        </TabsList>

        <div className="flex items-center gap-2 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search by name or location..."
              className="pl-10 pr-10 border-primary/20 focus-visible:ring-primary/30"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            {searchQuery && (
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-1 top-1/2 h-7 w-7 -translate-y-1/2"
                onClick={() => setSearchQuery("")}
              >
                <AlertCircle className="h-4 w-4" />
              </Button>
            )}
          </div>
          <Button
            variant="outline"
            size="icon"
            className="border-primary/20 hover:bg-primary/10"
            onClick={() => setIsFiltersOpen(!isFiltersOpen)}
          >
            <Filter className="h-4 w-4" />
          </Button>
        </div>

        {isFiltersOpen && (
          <Card className="mb-4 border-primary/20 animate-fade-in">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Filter Stations</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="filter-status">Status</Label>
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger id="filter-status" className="border-primary/20">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="available">Available</SelectItem>
                      <SelectItem value="busy">Busy</SelectItem>
                      <SelectItem value="maintenance">Maintenance</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="filter-charging-speed">Charging Speed</Label>
                  <Select value={filterChargingSpeed} onValueChange={setFilterChargingSpeed}>
                    <SelectTrigger id="filter-charging-speed" className="border-primary/20">
                      <SelectValue placeholder="Select charging speed" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Speeds</SelectItem>
                      <SelectItem value="standard">Standard (&lt; 100 kW)</SelectItem>
                      <SelectItem value="fast">Fast (100-200 kW)</SelectItem>
                      <SelectItem value="ultra">Ultra Fast (&gt; 200 kW)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="filter-available">Show Only Available</Label>
                    <Switch id="filter-available" checked={showOnlyAvailable} onCheckedChange={setShowOnlyAvailable} />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="filter-distance">Maximum Distance: {filterDistance[0]} miles</Label>
                </div>
                <Slider
                  id="filter-distance"
                  min={1}
                  max={20}
                  step={1}
                  value={filterDistance}
                  onValueChange={setFilterDistance}
                  className="py-2"
                />
              </div>
            </CardContent>
            <CardFooter className="flex justify-between pt-0">
              <Button
                variant="outline"
                onClick={() => {
                  setFilterStatus("all")
                  setFilterChargingSpeed("all")
                  setFilterDistance([10])
                  setShowOnlyAvailable(true)
                }}
              >
                Reset Filters
              </Button>
              <Button onClick={() => setIsFiltersOpen(false)}>Apply Filters</Button>
            </CardFooter>
          </Card>
        )}

        <TabsContent value="map" className="space-y-4">
          <div className="grid gap-6 md:grid-cols-[300px_1fr]">
            <div className="space-y-4">
              <Card className="border-2 border-primary/10 shadow-md bg-gradient-to-br from-background to-muted/30">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Nearby Stations</CardTitle>
                  <CardDescription>
                    {filteredStations.length} stations found within {filterDistance[0]} miles
                  </CardDescription>
                </CardHeader>
                <CardContent className="h-[300px] overflow-auto pr-2">
                  <div className="space-y-2">
                    {filteredStations.length > 0 ? (
                      filteredStations.map((station) => (
                        <div
                          key={station.id}
                          className={`p-3 border rounded-lg cursor-pointer transition-all ${
                            selectedStation?.id === station.id
                              ? "border-primary bg-primary/5"
                              : "hover:bg-muted/50 border-border"
                          }`}
                          onClick={() => handleStationClick(station)}
                        >
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <h4 className="font-medium text-sm">{station.name}</h4>
                              <p className="text-xs text-muted-foreground">{station.location}</p>
                              <div className="flex items-center gap-1 mt-1">
                                <Badge className={`text-xs ${getStatusColor(station.status)}`}>
                                  {getStatusText(station.status)}
                                </Badge>
                                {station.distance !== undefined && (
                                  <span className="text-xs text-muted-foreground">{station.distance} mi</span>
                                )}
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-xs font-medium">
                                {station.available !== undefined && station.capacity !== undefined
                                  ? `${station.available}/${station.capacity}`
                                  : "N/A"}
                              </div>
                              <div className="text-xs text-muted-foreground">Available</div>
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="flex flex-col items-center justify-center h-full text-center p-4">
                        <AlertCircle className="h-8 w-8 text-muted-foreground mb-2" />
                        <p className="text-sm font-medium">No stations found</p>
                        <p className="text-xs text-muted-foreground mt-1">Try adjusting your filters</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {selectedStation && (
                <Card className="border-2 border-primary/10 shadow-md bg-gradient-to-br from-background to-muted/30 animate-fade-in">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-base">{selectedStation.name}</CardTitle>
                        <CardDescription>{selectedStation.location}</CardDescription>
                      </div>
                      <Badge className={getStatusColor(selectedStation.status)}>
                        {getStatusText(selectedStation.status)}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <div className="text-xs text-muted-foreground">Charging Speed</div>
                        <div className="font-medium text-sm">{selectedStation.chargingSpeed} kW</div>
                        <div className="text-xs text-muted-foreground">
                          {getChargingSpeedText(selectedStation.chargingSpeed)}
                        </div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground">Price</div>
                        <div className="font-medium text-sm">${selectedStation.pricePerKwh.toFixed(2)}/kWh</div>
                      </div>
                    </div>

                    <div>
                      <div className="text-xs text-muted-foreground mb-1">Availability</div>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span>
                          {selectedStation.available}/{selectedStation.capacity} Available
                        </span>
                        <span>
                          {selectedStation.waitTime !== null && selectedStation.waitTime !== undefined
                            ? `${selectedStation.waitTime} min wait`
                            : "No wait time data"}
                        </span>
                      </div>
                      <Progress
                        value={
                          selectedStation.capacity ? (selectedStation.available! / selectedStation.capacity) * 100 : 0
                        }
                        className="h-2"
                      />
                    </div>

                    <div>
                      <div className="text-xs text-muted-foreground mb-1">Charger Types</div>
                      <div className="flex flex-wrap gap-1">
                        {selectedStation.chargerTypes.map((type, index) => (
                          <Badge
                            key={index}
                            variant="outline"
                            className="text-xs bg-primary/10 text-primary border-primary/20"
                          >
                            {type}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <div className="text-xs text-muted-foreground mb-1">Amenities</div>
                      <div className="flex flex-wrap gap-1">
                        {selectedStation.amenities.map((amenity, index) => (
                          <Badge
                            key={index}
                            variant="outline"
                            className="text-xs bg-secondary/10 text-secondary border-secondary/20"
                          >
                            {amenity}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90">
                      Navigate Here
                    </Button>
                  </CardFooter>
                </Card>
              )}
            </div>

            <div className="relative rounded-lg border overflow-hidden" style={{ height: "600px" }}>
              <div className={`absolute inset-0 ${mapView === "satellite" ? "map-satellite" : "map-standard"}`}>
                {/* Map container */}
                <div className="absolute inset-0">
                  {/* Charging stations */}
                  {filteredStations.map((station) => (
                    <div
                      key={station.id}
                      style={{
                        position: "absolute",
                        left: `${Math.random() * 80 + 10}%`,
                        top: `${Math.random() * 80 + 10}%`,
                      }}
                    >
                      <div
                        className={`charging-station ${station.status === "available" ? "pulse-animation" : ""} ${
                          selectedStation?.id === station.id ? "ring-4 ring-primary ring-opacity-50" : ""
                        }`}
                        onClick={() => handleStationClick(station)}
                      >
                        <BatteryCharging className="h-4 w-4" />
                      </div>
                      <div className="charging-station-tooltip">
                        <div className="font-medium">{station.name}</div>
                        <div className="text-xs text-muted-foreground">{station.location}</div>
                        <div className="flex items-center mt-1">
                          <Badge className={`text-xs ${getStatusColor(station.status)}`}>
                            {getStatusText(station.status)}
                          </Badge>
                          {station.waitTime !== null && station.waitTime !== undefined && station.waitTime > 0 && (
                            <span className="text-xs ml-2">{station.waitTime} min wait</span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* Current location marker */}
                  <div style={{ position: "absolute", left: "50%", top: "50%" }}>
                    <div className="w-6 h-6 bg-blue-500 rounded-full border-2 border-white flex items-center justify-center">
                      <Car className="h-3 w-3 text-white" />
                    </div>
                  </div>

                  {/* Route line (simplified) */}
                  <svg className="absolute inset-0 w-full h-full" style={{ pointerEvents: "none" }}>
                    <path
                      d="M 100,200 C 200,100 300,300 400,200"
                      stroke="hsl(var(--primary))"
                      strokeWidth="3"
                      fill="none"
                      strokeDasharray="5,5"
                    />
                  </svg>
                </div>

                {/* Map controls */}
                <div className="absolute top-4 right-4 z-10 flex flex-col gap-2">
                  <Button variant="outline" size="icon" className="bg-background/80 backdrop-blur-sm">
                    <Zap className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon" className="bg-background/80 backdrop-blur-sm">
                    <Info className="h-4 w-4" />
                  </Button>
                </div>

                {/* Map legend */}
                <div className="absolute bottom-4 left-4 z-10 bg-background/80 backdrop-blur-sm p-2 rounded-lg border shadow-sm">
                  <div className="text-xs font-medium mb-1">Legend</div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-3 h-3 rounded-full bg-success"></div>
                    <span>Available</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-3 h-3 rounded-full bg-warning"></div>
                    <span>Busy</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-3 h-3 rounded-full bg-destructive"></div>
                    <span>Maintenance</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="list" className="space-y-4">
          <div className="grid gap-4">
            {filteredStations.length > 0 ? (
              filteredStations.map((station) => (
                <Card
                  key={station.id}
                  className={`border-l-4 ${
                    station.status === "available"
                      ? "border-l-success"
                      : station.status === "busy"
                        ? "border-l-warning"
                        : "border-l-destructive"
                  } hover:shadow-md transition-shadow cursor-pointer enhanced-card`}
                  onClick={() => handleStationClick(station)}
                >
                  <CardHeader className="pb-2">
                    <div className="flex justify-between">
                      <CardTitle className="text-base">{station.name}</CardTitle>
                      <Badge className={getStatusColor(station.status)}>{getStatusText(station.status)}</Badge>
                    </div>
                    <CardDescription>{station.location}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-4 gap-4">
                      <div>
                        <div className="text-xs text-muted-foreground">Distance</div>
                        <div className="font-medium">{station.distance} mi</div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground">Charging</div>
                        <div className="font-medium">{station.chargingSpeed} kW</div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground">Price</div>
                        <div className="font-medium">${station.pricePerKwh.toFixed(2)}/kWh</div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground">Availability</div>
                        <div className="font-medium">
                          {station.available !== undefined && station.capacity !== undefined
                            ? `${station.available}/${station.capacity}`
                            : "N/A"}
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {station.chargerTypes.map((type, index) => (
                        <Badge
                          key={index}
                          variant="outline"
                          className="text-xs bg-primary/10 text-primary border-primary/20"
                        >
                          {type}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {station.amenities.slice(0, 3).map((amenity, index) => (
                        <Badge
                          key={index}
                          variant="outline"
                          className="text-xs bg-secondary/10 text-secondary border-secondary/20"
                        >
                          {amenity}
                        </Badge>
                      ))}
                      {station.amenities.length > 3 && (
                        <Badge variant="outline" className="text-xs bg-secondary/10 text-secondary border-secondary/20">
                          +{station.amenities.length - 3} more
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                  <CardFooter className="pt-0 justify-end">
                    <Button size="sm" className="bg-gradient-to-r from-primary to-secondary hover:opacity-90">
                      Navigate
                    </Button>
                  </CardFooter>
                </Card>
              ))
            ) : (
              <div className="flex flex-col items-center justify-center p-8 border rounded-lg bg-muted/10">
                <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No charging stations found</h3>
                <p className="text-muted-foreground mt-1 mb-4">Try adjusting your filters or search criteria</p>
                <Button
                  variant="outline"
                  onClick={() => {
                    setFilterStatus("all")
                    setFilterChargingSpeed("all")
                    setFilterDistance([10])
                    setShowOnlyAvailable(true)
                    setSearchQuery("")
                  }}
                >
                  Reset Filters
                </Button>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="route" className="space-y-4">
          <Card className="border-2 border-primary/10 shadow-md bg-gradient-to-br from-background to-muted/30">
            <CardHeader>
              <CardTitle>Route Planning</CardTitle>
              <CardDescription>Plan your journey with optimal charging stops</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="start-location">Start Location</Label>
                    <div className="flex items-center gap-2">
                      <div className="relative flex-1">
                        <MapPin className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-primary" />
                        <Input
                          id="start-location"
                          placeholder="Current Location"
                          className="pl-10 border-primary/20 focus-visible:ring-primary/30"
                          defaultValue="Current Location"
                        />
                      </div>
                      <Button variant="outline" size="icon" className="border-primary/20 hover:bg-primary/10">
                        <Compass className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="destination">Destination</Label>
                    <div className="flex items-center gap-2">
                      <div className="relative flex-1">
                        <MapPin className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-secondary" />
                        <Input
                          id="destination"
                          placeholder="Enter destination"
                          className="pl-10 border-primary/20 focus-visible:ring-primary/30"
                          defaultValue="123 Main St, Downtown"
                        />
                      </div>
                      <Button variant="outline" size="icon" className="border-primary/20 hover:bg-primary/10">
                        <Search className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Vehicle Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-3 border rounded-md bg-muted/10">
                      <div className="text-xs text-muted-foreground">Current Range</div>
                      <div className="font-medium">120 mi</div>
                      <Progress value={45} className="h-1.5 mt-1" />
                    </div>
                    <div className="p-3 border rounded-md bg-muted/10">
                      <div className="text-xs text-muted-foreground">Battery Level</div>
                      <div className="font-medium">45%</div>
                      <Progress value={45} className="h-1.5 mt-1" />
                    </div>
                    <div className="p-3 border rounded-md bg-muted/10">
                      <div className="text-xs text-muted-foreground">Consumption</div>
                      <div className="font-medium">290 Wh/mi</div>
                      <div className="text-xs text-muted-foreground mt-1">Average</div>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-medium">Recommended Charging Stops</h3>
                    <Button variant="outline" size="sm" className="text-xs border-primary/20 hover:bg-primary/10">
                      <Filter className="h-3 w-3 mr-1" /> Preferences
                    </Button>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-3 border rounded-md bg-success/5 hover:bg-success/10 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="rounded-full bg-success/20 p-2">
                          <BatteryCharging className="h-4 w-4 text-success" />
                        </div>
                        <div>
                          <div className="font-medium">GreenCharge Downtown</div>
                          <div className="text-xs text-muted-foreground">
                            At mile 45 • 20 min charge • 4/6 available
                          </div>
                        </div>
                      </div>
                      <Badge className="bg-success text-success-foreground">Recommended</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-md hover:bg-muted/10 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="rounded-full bg-primary/20 p-2">
                          <BatteryCharging className="h-4 w-4 text-primary" />
                        </div>
                        <div>
                          <div className="font-medium">EcoStation University</div>
                          <div className="text-xs text-muted-foreground">
                            At mile 78 • 15 min charge • 1/8 available
                          </div>
                        </div>
                      </div>
                      <Badge variant="outline" className="border-primary/20 bg-primary/5 text-primary">
                        Alternative
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-md hover:bg-muted/10 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="rounded-full bg-primary/20 p-2">
                          <BatteryCharging className="h-4 w-4 text-primary" />
                        </div>
                        <div>
                          <div className="font-medium">PowerUp Industrial</div>
                          <div className="text-xs text-muted-foreground">
                            At mile 110 • 25 min charge • 3/4 available
                          </div>
                        </div>
                      </div>
                      <Badge variant="outline" className="border-primary/20 bg-primary/5 text-primary">
                        Alternative
                      </Badge>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Journey Summary</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-3 border rounded-md bg-muted/10">
                      <div className="text-xs text-muted-foreground">Total Distance</div>
                      <div className="font-medium">145 miles</div>
                      <div className="text-xs text-muted-foreground mt-1">Estimated</div>
                    </div>
                    <div className="p-3 border rounded-md bg-muted/10">
                      <div className="text-xs text-muted-foreground">Travel Time</div>
                      <div className="font-medium">2h 35m</div>
                      <div className="text-xs text-muted-foreground mt-1">Including charging</div>
                    </div>
                    <div className="p-3 border rounded-md bg-muted/10">
                      <div className="text-xs text-muted-foreground">Arrival Battery</div>
                      <div className="font-medium">65%</div>
                      <Progress value={65} className="h-1.5 mt-1" />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90">
                Start Navigation
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

