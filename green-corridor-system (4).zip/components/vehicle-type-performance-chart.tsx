"use client"

import { Skeleton } from "@/components/ui/skeleton"
import {
  Chart,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
} from "@/components/ui/chart"

interface VehicleTypePerformanceChartProps {
  isLoading: boolean
  data?: {
    type: string
    efficiency: number
    energySavings: number
    emissionsReduction: number
    trafficFlow: number
    adaptability: number
  }[]
}

export function VehicleTypePerformanceChart({ isLoading, data }: VehicleTypePerformanceChartProps) {
  if (isLoading || !data) {
    return <Skeleton className="h-[400px] w-full" />
  }

  return (
    <ChartContainer className="h-[400px]">
      <Chart className="h-full">
        <PolarGrid />
        <PolarAngleAxis dataKey="type" />
        <ChartTooltip
          content={
            <ChartTooltipContent
              className="border-none bg-background/80 backdrop-blur-sm"
              valueFormatter={(value) => `${value}%`}
            />
          }
        />
        <RadarChart data={data}>
          <Radar
            dataKey="efficiency"
            name="Efficiency"
            fill="hsl(var(--primary))"
            fillOpacity={0.2}
            stroke="hsl(var(--primary))"
          />
          <Radar
            dataKey="energySavings"
            name="Energy Savings"
            fill="hsl(var(--primary)/0.7)"
            fillOpacity={0.2}
            stroke="hsl(var(--primary)/0.7)"
          />
          <Radar
            dataKey="emissionsReduction"
            name="Emissions Reduction"
            fill="hsl(var(--primary)/0.5)"
            fillOpacity={0.2}
            stroke="hsl(var(--primary)/0.5)"
          />
          <Radar
            dataKey="trafficFlow"
            name="Traffic Flow"
            fill="hsl(var(--primary)/0.3)"
            fillOpacity={0.2}
            stroke="hsl(var(--primary)/0.3)"
          />
          <Radar
            dataKey="adaptability"
            name="Adaptability"
            fill="hsl(var(--primary)/0.1)"
            fillOpacity={0.2}
            stroke="hsl(var(--primary)/0.1)"
          />
        </RadarChart>
      </Chart>
    </ChartContainer>
  )
}

