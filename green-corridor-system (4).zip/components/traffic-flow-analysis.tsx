// Add a new component for traffic flow analysis
"use client"

import { useState, useEffect } from "react"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, TrendingUp, TrendingDown, ArrowRight, Clock, Car, BarChart3 } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Chart,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  LinearGradient,
  LinearGradientStop,
  XAxis,
  YAxis,
  Area,
  AreaChart,
  Bar,
  BarChart,
} from "@/components/ui/chart"

interface TrafficFlowAnalysisProps {
  isLoading?: boolean
  data?: any
  timeRange?: string
}

export function TrafficFlowAnalysis({ isLoading = false, data, timeRange = "24h" }: TrafficFlowAnalysisProps) {
  const [error, setError] = useState<string | null>(null)
  const [chartData, setChartData] = useState<any[] | null>(null)
  const [corridorData, setCorridorData] = useState<any[] | null>(null)

  useEffect(() => {
    if (!isLoading && data) {
      try {
        // Process data for the chart
        setChartData(data.trafficFlow || [])
        setCorridorData(data.corridorPerformance || [])
        setError(null)
      } catch (err) {
        console.error("Error processing traffic flow data:", err)
        setError("Failed to process traffic flow data")
      }
    }
  }, [isLoading, data])

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-[300px] w-full" />
        <div className="grid grid-cols-3 gap-4">
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-24 w-full" />
        </div>
        <Skeleton className="h-[200px] w-full" />
      </div>
    )
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    )
  }

  if (!chartData || chartData.length === 0 || !corridorData || corridorData.length === 0) {
    return (
      <div className="h-[300px] w-full flex items-center justify-center border rounded-md">
        <p className="text-muted-foreground">No traffic flow data available</p>
      </div>
    )
  }

  // Calculate average traffic volume
  const averageTraffic = chartData.reduce((sum: number, item: any) => sum + item.value, 0) / chartData.length

  // Find peak traffic time and value
  const peakTraffic = chartData.reduce((max: any, item: any) => (item.value > max.value ? item : max), chartData[0])
  const peakTime = new Date(peakTraffic.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })

  // Calculate traffic efficiency
  const trafficEfficiency = 87 // This would normally be calculated from the data

  // Separate actual and predicted data
  const actualData = chartData.filter((item: any) => !item.prediction)
  const predictedData = chartData.filter((item: any) => item.prediction)

  return (
    <div className="space-y-6">
      <Card className="border-2 border-primary/10 shadow-md">
        <CardHeader>
          <CardTitle>Traffic Flow Analysis</CardTitle>
          <CardDescription>Real-time and predicted traffic patterns across all corridors</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="rounded-md border p-4 bg-gradient-to-br from-background to-muted/30">
              <div className="flex items-center gap-2 mb-1">
                <Car className="h-4 w-4 text-primary" />
                <div className="text-sm font-medium text-muted-foreground">Average Volume</div>
              </div>
              <div className="text-2xl font-bold">{Math.round(averageTraffic)}</div>
              <div className="text-xs text-muted-foreground">vehicles per hour</div>
              <div className="flex items-center gap-1 mt-2">
                <TrendingUp className="h-3 w-3 text-success" />
                <span className="text-xs text-success">+12% from last week</span>
              </div>
            </div>

            <div className="rounded-md border p-4 bg-gradient-to-br from-background to-muted/30">
              <div className="flex items-center gap-2 mb-1">
                <Clock className="h-4 w-4 text-primary" />
                <div className="text-sm font-medium text-muted-foreground">Peak Time</div>
              </div>
              <div className="text-2xl font-bold">{peakTime}</div>
              <div className="text-xs text-muted-foreground">{peakTraffic.value} vehicles</div>
              <div className="flex items-center gap-1 mt-2">
                <TrendingDown className="h-3 w-3 text-success" />
                <span className="text-xs text-success">15 min earlier than usual</span>
              </div>
            </div>

            <div className="rounded-md border p-4 bg-gradient-to-br from-background to-muted/30">
              <div className="flex items-center gap-2 mb-1">
                <BarChart3 className="h-4 w-4 text-primary" />
                <div className="text-sm font-medium text-muted-foreground">Traffic Efficiency</div>
              </div>
              <div className="text-2xl font-bold">{trafficEfficiency}%</div>
              <div className="text-xs text-muted-foreground">overall system performance</div>
              <div className="flex items-center gap-1 mt-2">
                <TrendingUp className="h-3 w-3 text-success" />
                <span className="text-xs text-success">+5% from last month</span>
              </div>
            </div>
          </div>

          <ChartContainer className="h-[300px]">
            <Chart className="h-full">
              <LinearGradient id="trafficGradient" direction="bottom">
                <LinearGradientStop offset="0%" color="hsl(var(--primary))" opacity={0.2} />
                <LinearGradientStop offset="100%" color="hsl(var(--primary))" opacity={0} />
              </LinearGradient>
              <LinearGradient id="predictedGradient" direction="bottom">
                <LinearGradientStop offset="0%" color="hsl(var(--secondary))" opacity={0.1} />
                <LinearGradientStop offset="100%" color="hsl(var(--secondary))" opacity={0} />
              </LinearGradient>
              <XAxis
                dataKey="timestamp"
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => {
                  const date = new Date(value)
                  return `${date.getHours()}:00`
                }}
                fontSize={12}
                tickMargin={12}
              />
              <YAxis
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => `${value}`}
                fontSize={12}
                tickMargin={12}
              />
              <ChartTooltip
                content={
                  <ChartTooltipContent
                    className="border-none bg-background/80 backdrop-blur-sm"
                    labelFormatter={(label) => {
                      const date = new Date(label)
                      return `${date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`
                    }}
                    valueFormatter={(value) => `${value} vehicles`}
                  />
                }
              />
              <AreaChart data={actualData}>
                <Area dataKey="value" stroke="hsl(var(--primary))" fill="url(#trafficGradient)" strokeWidth={2} />
              </AreaChart>
              <AreaChart data={predictedData}>
                <Area
                  dataKey="value"
                  stroke="hsl(var(--secondary))"
                  fill="url(#predictedGradient)"
                  strokeWidth={2}
                  strokeDasharray="4 4"
                />
              </AreaChart>
            </Chart>
          </ChartContainer>

          <div className="flex justify-between text-xs text-muted-foreground">
            <div>
              <span className="inline-block w-3 h-1 bg-primary mr-1"></span>
              Actual Traffic
            </div>
            <div>
              <span className="inline-block w-3 h-1 bg-secondary mr-1 opacity-70 border-b border-dashed"></span>
              Predicted Traffic
            </div>
            <div>
              <span className="inline-block w-2 h-2 rounded-full bg-green-500 mr-1"></span>
              Optimal Flow
            </div>
            <div>
              <span className="inline-block w-2 h-2 rounded-full bg-yellow-500 mr-1"></span>
              Moderate Congestion
            </div>
            <div>
              <span className="inline-block w-2 h-2 rounded-full bg-red-500 mr-1"></span>
              Heavy Congestion
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="text-sm font-medium">Corridor Performance</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <ChartContainer className="h-[200px]">
                <Chart className="h-full">
                  <XAxis dataKey="name" tickLine={false} axisLine={false} fontSize={12} tickMargin={12} />
                  <YAxis
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(value) => `${value}%`}
                    fontSize={12}
                    tickMargin={12}
                  />
                  <ChartTooltip
                    content={
                      <ChartTooltipContent
                        className="border-none bg-background/80 backdrop-blur-sm"
                        valueFormatter={(value) => `${value}%`}
                      />
                    }
                  />
                  <BarChart data={corridorData}>
                    <Bar dataKey="efficiency" fill="hsl(var(--primary))" radius={4} />
                    <Bar dataKey="target" fill="hsl(var(--muted-foreground)/0.3)" radius={4} />
                  </BarChart>
                </Chart>
              </ChartContainer>

              <div className="space-y-2">
                {corridorData.map((corridor: any) => (
                  <div key={corridor.name} className="space-y-1">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-2 h-2 rounded-full ${
                            corridor.efficiency >= 90
                              ? "bg-green-500"
                              : corridor.efficiency >= 75
                                ? "bg-yellow-500"
                                : "bg-red-500"
                          }`}
                        ></div>
                        <span className="text-sm">{corridor.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm">{corridor.efficiency}%</span>
                        <Badge
                          variant="outline"
                          className={
                            corridor.efficiency >= corridor.target
                              ? "bg-green-500/10 text-green-500 border-green-500/20"
                              : "bg-yellow-500/10 text-yellow-500 border-yellow-500/20"
                          }
                        >
                          {corridor.efficiency >= corridor.target ? "On Target" : "Below Target"}
                        </Badge>
                      </div>
                    </div>
                    <Progress
                      value={corridor.efficiency}
                      className="h-1.5"
                      indicatorClassName={
                        corridor.efficiency >= 90
                          ? "bg-green-500"
                          : corridor.efficiency >= 75
                            ? "bg-yellow-500"
                            : "bg-red-500"
                      }
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="rounded-md border p-4 bg-gradient-to-br from-background to-muted/30">
              <h4 className="text-sm font-medium mb-2">Traffic Insights</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <TrendingUp className="h-4 w-4 text-success mt-0.5" />
                  <span>Main Street corridor showing 15% improved flow after signal timing adjustments</span>
                </li>
                <li className="flex items-start gap-2">
                  <AlertCircle className="h-4 w-4 text-warning mt-0.5" />
                  <span>Downtown corridor experiencing moderate congestion during 4-6 PM peak hours</span>
                </li>
                <li className="flex items-start gap-2">
                  <Clock className="h-4 w-4 text-primary mt-0.5" />
                  <span>University Avenue traffic patterns shifting earlier by 15 minutes compared to last month</span>
                </li>
              </ul>
            </div>

            <div className="rounded-md border p-4 bg-gradient-to-br from-background to-muted/30">
              <h4 className="text-sm font-medium mb-2">Recommendations</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <ArrowRight className="h-4 w-4 text-primary mt-0.5" />
                  <span>Adjust Downtown corridor signal timing by +5 seconds during 4-6 PM to reduce congestion</span>
                </li>
                <li className="flex items-start gap-2">
                  <ArrowRight className="h-4 w-4 text-primary mt-0.5" />
                  <span>Implement green wave for University Avenue during morning peak hours (7-9 AM)</span>
                </li>
                <li className="flex items-start gap-2">
                  <ArrowRight className="h-4 w-4 text-primary mt-0.5" />
                  <span>Consider temporary lane adjustments on Industrial Zone corridor during shift changes</span>
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

