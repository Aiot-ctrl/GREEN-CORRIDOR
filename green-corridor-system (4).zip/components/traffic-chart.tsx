"use client"

import { useState, useEffect } from "react"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"
import {
  Chart,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  LinearGradient,
  LinearGradientStop,
  XAxis,
  YAxis,
  Area,
  AreaChart,
} from "@/components/ui/chart"

interface TrafficChartProps {
  isLoading: boolean
  data?: {
    timestamp: string
    value: number
    prediction?: boolean
  }[]
}

export function TrafficChart({ isLoading, data }: TrafficChartProps) {
  const [error, setError] = useState<string | null>(null)
  const [chartData, setChartData] = useState<any[] | null>(null)

  useEffect(() => {
    if (!isLoading && data) {
      try {
        // Process data for the chart
        setChartData(data)
        setError(null)
      } catch (err) {
        console.error("Error processing traffic chart data:", err)
        setError("Failed to process traffic data")
      }
    }
  }, [isLoading, data])

  if (isLoading) {
    return <Skeleton className="h-[300px] w-full" />
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    )
  }

  if (!data || data.length === 0) {
    return (
      <div className="h-[300px] w-full flex items-center justify-center border rounded-md">
        <p className="text-muted-foreground">No traffic data available</p>
      </div>
    )
  }

  // Calculate average traffic volume
  const averageTraffic = data.reduce((sum, item) => sum + item.value, 0) / data.length

  // Find peak traffic time and value
  const peakTraffic = data.reduce((max, item) => (item.value > max.value ? item : max), data[0])
  const peakTime = new Date(peakTraffic.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })

  // Separate actual and predicted data
  const actualData = data.filter((item) => !item.prediction)
  const predictedData = data.filter((item) => item.prediction)

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-4">
        <div className="rounded-md border p-3 bg-gradient-to-br from-background to-muted/30">
          <div className="text-sm font-medium text-muted-foreground">Average Volume</div>
          <div className="text-2xl font-bold">{Math.round(averageTraffic)}</div>
          <div className="text-xs text-muted-foreground">vehicles per hour</div>
        </div>
        <div className="rounded-md border p-3 bg-gradient-to-br from-background to-muted/30">
          <div className="text-sm font-medium text-muted-foreground">Peak Time</div>
          <div className="text-2xl font-bold">{peakTime}</div>
          <div className="text-xs text-muted-foreground">{peakTraffic.value} vehicles</div>
        </div>
        <div className="rounded-md border p-3 bg-gradient-to-br from-background to-muted/30">
          <div className="text-sm font-medium text-muted-foreground">Current Status</div>
          <div className="text-2xl font-bold text-success">Optimal</div>
          <div className="text-xs text-muted-foreground">All corridors flowing</div>
        </div>
      </div>

      <ChartContainer className="h-[300px]">
        <Chart className="h-full">
          <LinearGradient id="trafficGradient" direction="bottom">
            <LinearGradientStop offset="0%" color="hsl(var(--primary))" opacity={0.2} />
            <LinearGradientStop offset="100%" color="hsl(var(--primary))" opacity={0} />
          </LinearGradient>
          <LinearGradient id="predictedGradient" direction="bottom">
            <LinearGradientStop offset="0%" color="hsl(var(--secondary))" opacity={0.1} />
            <LinearGradientStop offset="100%" color="hsl(var(--secondary))" opacity={0} />
          </LinearGradient>
          <XAxis
            dataKey="timestamp"
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) => {
              const date = new Date(value)
              return `${date.getHours()}:00`
            }}
            fontSize={12}
            tickMargin={12}
          />
          <YAxis
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) => `${value}`}
            fontSize={12}
            tickMargin={12}
          />
          <ChartTooltip
            content={
              <ChartTooltipContent
                className="border-none bg-background/80 backdrop-blur-sm"
                labelFormatter={(label) => {
                  const date = new Date(label)
                  return `${date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`
                }}
                valueFormatter={(value) => `${value} vehicles`}
              />
            }
          />
          <AreaChart data={actualData}>
            <Area dataKey="value" stroke="hsl(var(--primary))" fill="url(#trafficGradient)" strokeWidth={2} />
          </AreaChart>
          <AreaChart data={predictedData}>
            <Area
              dataKey="value"
              stroke="hsl(var(--secondary))"
              fill="url(#predictedGradient)"
              strokeWidth={2}
              strokeDasharray="4 4"
            />
          </AreaChart>
        </Chart>
      </ChartContainer>

      <div className="flex justify-between text-xs text-muted-foreground">
        <div>
          <span className="inline-block w-3 h-1 bg-primary mr-1"></span>
          Actual Traffic
        </div>
        <div>
          <span className="inline-block w-3 h-1 bg-secondary mr-1 opacity-70 border-b border-dashed"></span>
          Predicted Traffic
        </div>
        <div>
          <span className="inline-block w-2 h-2 rounded-full bg-green-500 mr-1"></span>
          Optimal Flow
        </div>
        <div>
          <span className="inline-block w-2 h-2 rounded-full bg-yellow-500 mr-1"></span>
          Moderate Congestion
        </div>
        <div>
          <span className="inline-block w-2 h-2 rounded-full bg-red-500 mr-1"></span>
          Heavy Congestion
        </div>
      </div>
    </div>
  )
}

