"use client"

import { Badge } from "@/components/ui/badge"

import { useState } from "react"
import { Calendar, Download, FileText, Printer, Share2 } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { DatePickerWithRange } from "@/components/date-range-picker"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function ReportGenerator() {
  const [isGenerating, setIsGenerating] = useState(false)
  const [reportGenerated, setReportGenerated] = useState(false)

  const handleGenerateReport = () => {
    setIsGenerating(true)
    // Simulate report generation
    setTimeout(() => {
      setIsGenerating(false)
      setReportGenerated(true)
    }, 2000)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Report Generator</h2>
        <Button variant="outline">
          <Calendar className="mr-2 h-4 w-4" />
          View Scheduled Reports
        </Button>
      </div>

      <Tabs defaultValue="custom">
        <TabsList>
          <TabsTrigger value="custom">Custom Report</TabsTrigger>
          <TabsTrigger value="templates">Report Templates</TabsTrigger>
          <TabsTrigger value="scheduled">Schedule Report</TabsTrigger>
        </TabsList>

        <TabsContent value="custom" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Custom Report Configuration</CardTitle>
              <CardDescription>Select metrics and parameters to include in your report</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="report-title">Report Title</Label>
                  <Input id="report-title" placeholder="Green Corridor System Performance Report" />
                </div>

                <div className="space-y-2">
                  <Label>Date Range</Label>
                  <DatePickerWithRange />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="report-format">Report Format</Label>
                  <Select defaultValue="pdf">
                    <SelectTrigger id="report-format">
                      <SelectValue placeholder="Select format" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pdf">PDF Document</SelectItem>
                      <SelectItem value="excel">Excel Spreadsheet</SelectItem>
                      <SelectItem value="csv">CSV Data</SelectItem>
                      <SelectItem value="json">JSON Data</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-3">
                <Label>Metrics to Include</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-start space-x-2">
                    <Checkbox id="traffic-flow" defaultChecked />
                    <div className="grid gap-1.5 leading-none">
                      <Label htmlFor="traffic-flow">Traffic Flow</Label>
                      <p className="text-sm text-muted-foreground">Traffic volume and patterns</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Checkbox id="vehicle-distribution" defaultChecked />
                    <div className="grid gap-1.5 leading-none">
                      <Label htmlFor="vehicle-distribution">Vehicle Distribution</Label>
                      <p className="text-sm text-muted-foreground">Breakdown of vehicle types</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Checkbox id="corridor-performance" defaultChecked />
                    <div className="grid gap-1.5 leading-none">
                      <Label htmlFor="corridor-performance">Corridor Performance</Label>
                      <p className="text-sm text-muted-foreground">Efficiency metrics by corridor</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Checkbox id="energy-savings" defaultChecked />
                    <div className="grid gap-1.5 leading-none">
                      <Label htmlFor="energy-savings">Energy Savings</Label>
                      <p className="text-sm text-muted-foreground">Energy conservation metrics</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Checkbox id="emissions" defaultChecked />
                    <div className="grid gap-1.5 leading-none">
                      <Label htmlFor="emissions">Emissions Reduction</Label>
                      <p className="text-sm text-muted-foreground">Environmental impact data</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Checkbox id="system-health" />
                    <div className="grid gap-1.5 leading-none">
                      <Label htmlFor="system-health">System Health</Label>
                      <p className="text-sm text-muted-foreground">Component status and alerts</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Checkbox id="ai-insights" />
                    <div className="grid gap-1.5 leading-none">
                      <Label htmlFor="ai-insights">AI Insights</Label>
                      <p className="text-sm text-muted-foreground">AI-generated recommendations</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Checkbox id="predictions" />
                    <div className="grid gap-1.5 leading-none">
                      <Label htmlFor="predictions">Predictive Analytics</Label>
                      <p className="text-sm text-muted-foreground">Future traffic and performance predictions</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline">Reset</Button>
              <Button onClick={handleGenerateReport} disabled={isGenerating}>
                {isGenerating ? (
                  <>
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
                    Generating...
                  </>
                ) : (
                  <>
                    <FileText className="mr-2 h-4 w-4" />
                    Generate Report
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>

          {reportGenerated && (
            <Card>
              <CardHeader>
                <CardTitle>Report Generated</CardTitle>
                <CardDescription>Your report has been successfully generated</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-lg border p-6 flex flex-col items-center justify-center">
                  <FileText className="h-16 w-16 text-primary mb-4" />
                  <h3 className="text-xl font-bold mb-2">Green Corridor System Performance Report</h3>
                  <p className="text-sm text-muted-foreground mb-6">March 1, 2025 - March 16, 2025</p>
                  <div className="flex gap-4">
                    <Button>
                      <Download className="mr-2 h-4 w-4" />
                      Download
                    </Button>
                    <Button variant="outline">
                      <Printer className="mr-2 h-4 w-4" />
                      Print
                    </Button>
                    <Button variant="outline">
                      <Share2 className="mr-2 h-4 w-4" />
                      Share
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Daily Performance Summary</CardTitle>
                <CardDescription>Complete daily overview of system performance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-primary" />
                    <span className="font-medium">Comprehensive daily report</span>
                  </div>
                  <Button size="sm">Use Template</Button>
                </div>
                <div className="text-sm text-muted-foreground">
                  Includes traffic flow, energy savings, and system health metrics for the past 24 hours.
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Weekly Executive Summary</CardTitle>
                <CardDescription>High-level overview for management</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-primary" />
                    <span className="font-medium">Executive dashboard report</span>
                  </div>
                  <Button size="sm">Use Template</Button>
                </div>
                <div className="text-sm text-muted-foreground">
                  Summarizes key performance indicators, trends, and recommendations for the past week.
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Environmental Impact Report</CardTitle>
                <CardDescription>Detailed environmental metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-primary" />
                    <span className="font-medium">Environmental analysis</span>
                  </div>
                  <Button size="sm">Use Template</Button>
                </div>
                <div className="text-sm text-muted-foreground">
                  Focuses on emissions reduction, energy savings, and environmental impact of the system.
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Corridor Comparison</CardTitle>
                <CardDescription>Performance analysis by corridor</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-primary" />
                    <span className="font-medium">Corridor efficiency report</span>
                  </div>
                  <Button size="sm">Use Template</Button>
                </div>
                <div className="text-sm text-muted-foreground">
                  Compares performance metrics across all corridors with detailed analysis.
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Vehicle Type Analysis</CardTitle>
                <CardDescription>Detailed breakdown by vehicle type</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-primary" />
                    <span className="font-medium">Vehicle performance report</span>
                  </div>
                  <Button size="sm">Use Template</Button>
                </div>
                <div className="text-sm text-muted-foreground">
                  Analyzes performance metrics for EVs, AVs, and traditional vehicles in the system.
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>AI Insights Report</CardTitle>
                <CardDescription>AI-generated recommendations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-primary" />
                    <span className="font-medium">AI analysis and insights</span>
                  </div>
                  <Button size="sm">Use Template</Button>
                </div>
                <div className="text-sm text-muted-foreground">
                  Compiles AI-generated insights, predictions, and optimization recommendations.
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="scheduled" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Schedule Automated Reports</CardTitle>
              <CardDescription>Configure reports to be generated and delivered automatically</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="schedule-report">Report Type</Label>
                  <Select defaultValue="daily-summary">
                    <SelectTrigger id="schedule-report">
                      <SelectValue placeholder="Select report type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily-summary">Daily Performance Summary</SelectItem>
                      <SelectItem value="weekly-executive">Weekly Executive Summary</SelectItem>
                      <SelectItem value="environmental">Environmental Impact Report</SelectItem>
                      <SelectItem value="corridor">Corridor Comparison</SelectItem>
                      <SelectItem value="vehicle">Vehicle Type Analysis</SelectItem>
                      <SelectItem value="ai-insights">AI Insights Report</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="schedule-frequency">Frequency</Label>
                  <Select defaultValue="daily">
                    <SelectTrigger id="schedule-frequency">
                      <SelectValue placeholder="Select frequency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="biweekly">Bi-weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="schedule-time">Delivery Time</Label>
                  <Select defaultValue="morning">
                    <SelectTrigger id="schedule-time">
                      <SelectValue placeholder="Select delivery time" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="morning">Morning (8:00 AM)</SelectItem>
                      <SelectItem value="noon">Noon (12:00 PM)</SelectItem>
                      <SelectItem value="evening">Evening (6:00 PM)</SelectItem>
                      <SelectItem value="night">Night (10:00 PM)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="delivery-method">Delivery Method</Label>
                  <Select defaultValue="email">
                    <SelectTrigger id="delivery-method">
                      <SelectValue placeholder="Select delivery method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="email">Email</SelectItem>
                      <SelectItem value="dashboard">Dashboard</SelectItem>
                      <SelectItem value="both">Both Email and Dashboard</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="recipients">Email Recipients</Label>
                <Input id="recipients" placeholder="email@example.com, another@example.com" />
                <p className="text-xs text-muted-foreground">Separate multiple email addresses with commas</p>
              </div>

              <div className="flex items-start space-x-2">
                <Checkbox id="include-attachments" defaultChecked />
                <div className="grid gap-1.5 leading-none">
                  <Label htmlFor="include-attachments">Include Attachments</Label>
                  <p className="text-sm text-muted-foreground">Attach report files to email (PDF and Excel formats)</p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline">Cancel</Button>
              <Button>
                <Calendar className="mr-2 h-4 w-4" />
                Schedule Report
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Currently Scheduled Reports</CardTitle>
              <CardDescription>View and manage your scheduled reports</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="rounded-md border p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium">Daily Performance Summary</h3>
                    <Badge>Daily</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">Delivered at 8:00 AM to admin@greencorridor.com</p>
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" size="sm">
                      Edit
                    </Button>
                    <Button variant="destructive" size="sm">
                      Delete
                    </Button>
                  </div>
                </div>

                <div className="rounded-md border p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium">Weekly Executive Summary</h3>
                    <Badge>Weekly</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">
                    Delivered every Monday at 6:00 AM to management@greencorridor.com
                  </p>
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" size="sm">
                      Edit
                    </Button>
                    <Button variant="destructive" size="sm">
                      Delete
                    </Button>
                  </div>
                </div>

                <div className="rounded-md border p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium">Environmental Impact Report</h3>
                    <Badge>Monthly</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">
                    Delivered on the 1st of each month at 12:00 PM to environmental@greencorridor.com
                  </p>
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" size="sm">
                      Edit
                    </Button>
                    <Button variant="destructive" size="sm">
                      Delete
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

