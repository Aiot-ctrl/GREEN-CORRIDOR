"use client"

import { Skeleton } from "@/components/ui/skeleton"
import { Chart, ChartContainer, ChartTooltip, ChartTooltipContent, Pie, PieChart } from "@/components/ui/chart"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

interface VehicleDistributionChartProps {
  isLoading: boolean
  data?: {
    name: string
    value: number
    color: string
  }[]
}

export function VehicleDistributionChart({ isLoading, data }: VehicleDistributionChartProps) {
  if (isLoading || !data) {
    return <Skeleton className="h-[300px] w-full" />
  }

  return (
    <div className="space-y-4">
      <ChartContainer className="h-[300px]">
        <Chart className="h-full">
          <ChartTooltip
            content={
              <ChartTooltipContent
                className="border-none bg-background/80 backdrop-blur-sm"
                valueFormatter={(value) => `${value}%`}
              />
            }
          />
          <PieChart data={data} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80}>
            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              cx="50%"
              cy="50%"
              outerRadius={80}
              fill={(entry) => entry.color}
              label={(entry) => `${entry.name}: ${entry.value}%`}
              labelLine={false}
            />
          </PieChart>
        </Chart>
      </ChartContainer>

      <div className="grid grid-cols-3 gap-4">
        {data.map((item) => (
          <Card key={item.name} className="rounded-md border p-3 bg-gradient-to-br from-background to-muted/30">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
              <div className="text-sm font-medium">{item.name}</div>
            </div>
            <div className="text-2xl font-bold mt-1">{item.value}%</div>
            <div className="text-xs text-muted-foreground">
              {item.name === "Electric Vehicles" && "15% increase from last month"}
              {item.name === "Autonomous Vehicles" && "8% increase from last month"}
              {item.name === "Traditional Vehicles" && "12% decrease from last month"}
            </div>
          </Card>
        ))}
      </div>

      <Card className="rounded-md border p-3 bg-gradient-to-br from-background to-muted/30">
        <h4 className="text-sm font-medium mb-2">Vehicle Type Trends</h4>
        <div className="space-y-3">
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span>Electric Vehicles Adoption</span>
              <span className="font-medium">+15%</span>
            </div>
            <Progress value={75} className="h-1.5" />
          </div>
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span>Autonomous Vehicles Adoption</span>
              <span className="font-medium">+8%</span>
            </div>
            <Progress value={58} className="h-1.5" />
          </div>
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span>Traditional Vehicles Reduction</span>
              <span className="font-medium">-12%</span>
            </div>
            <Progress value={42} className="h-1.5" />
          </div>
        </div>
      </Card>
    </div>
  )
}

