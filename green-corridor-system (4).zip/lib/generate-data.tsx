// Utility function to generate random data for the application

// Generate random number between min and max
function randomNumber(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1) + min)
}

// Generate random traffic flow data
export function generateTrafficData() {
  // Traffic flow data (hourly)
  const trafficFlow = Array.from({ length: 24 }, (_, i) => {
    // More traffic during rush hours (7-9 AM and 4-6 PM)
    let baseValue = 100
    if (i >= 7 && i <= 9) baseValue = 300
    if (i >= 16 && i <= 18) baseValue = 350

    const value = randomNumber(baseValue * 0.8, baseValue * 1.2)
    const prediction = i > 12 ? false : true

    return {
      timestamp: new Date(2025, 2, 16, i).toISOString(),
      value,
      prediction,
    }
  })

  // Vehicle distribution data
  const vehicleDistribution = [
    { name: "Electric Vehicles", value: randomNumber(25, 35), color: "#3b82f6" },
    { name: "Autonomous Vehicles", value: randomNumber(15, 25), color: "#8b5cf6" },
    { name: "Traditional Vehicles", value: randomNumber(45, 55), color: "#6b7280" },
  ]

  // Corridor performance data
  const corridorPerformance = [
    { name: "Main St", efficiency: randomNumber(75, 95), target: 90 },
    { name: "Downtown", efficiency: randomNumber(65, 85), target: 80 },
    { name: "University", efficiency: randomNumber(80, 95), target: 90 },
    { name: "Industrial", efficiency: randomNumber(70, 90), target: 85 },
    { name: "Suburban", efficiency: randomNumber(75, 90), target: 85 },
  ]

  // Energy savings data
  const energySavings = [
    { date: "Mar 10", amount: randomNumber(80, 120), cumulative: 80 },
    { date: "Mar 11", amount: randomNumber(90, 130), cumulative: 210 },
    { date: "Mar 12", amount: randomNumber(100, 140), cumulative: 340 },
    { date: "Mar 13", amount: randomNumber(110, 150), cumulative: 480 },
    { date: "Mar 14", amount: randomNumber(120, 160), cumulative: 630 },
    { date: "Mar 15", amount: randomNumber(130, 170), cumulative: 790 },
    { date: "Mar 16", amount: randomNumber(140, 180), cumulative: 960 },
  ]

  // Traffic signals data
  const trafficSignals = [
    { id: "S-001", location: "Main St & 1st Ave", status: "operational", lastUpdated: "2 mins ago", efficiency: 94 },
    { id: "S-002", location: "Main St & 2nd Ave", status: "operational", lastUpdated: "1 min ago", efficiency: 92 },
    { id: "S-003", location: "Downtown Blvd & Oak St", status: "warning", lastUpdated: "5 mins ago", efficiency: 78 },
    {
      id: "S-004",
      location: "University Ave & College St",
      status: "operational",
      lastUpdated: "3 mins ago",
      efficiency: 96,
    },
    {
      id: "S-005",
      location: "Industrial Pkwy & Factory Rd",
      status: "operational",
      lastUpdated: "2 mins ago",
      efficiency: 89,
    },
    { id: "S-006", location: "Downtown Blvd & Elm St", status: "warning", lastUpdated: "7 mins ago", efficiency: 72 },
    {
      id: "S-007",
      location: "Suburban Dr & Maple Ave",
      status: "operational",
      lastUpdated: "4 mins ago",
      efficiency: 91,
    },
    {
      id: "S-008",
      location: "University Ave & Research Dr",
      status: "operational",
      lastUpdated: "1 min ago",
      efficiency: 95,
    },
    { id: "S-009", location: "Main St & 3rd Ave", status: "maintenance", lastUpdated: "30 mins ago", efficiency: 0 },
    {
      id: "S-010",
      location: "Industrial Pkwy & Warehouse St",
      status: "operational",
      lastUpdated: "5 mins ago",
      efficiency: 87,
    },
  ]

  return {
    trafficFlow,
    vehicleDistribution,
    corridorPerformance,
    energySavings,
    trafficSignals,
  }
}

// Generate traffic map data
export function generateTrafficMapData(cityType = "metro-city") {
  // Generate roads based on city type
  const roads = []
  const signals = []
  const vehicles = []
  const chargingStations = [] // Add charging stations array

  // Different road layouts based on city type
  switch (cityType) {
    case "metro-city":
      // Grid layout for metro city
      for (let i = 0; i < 5; i++) {
        // Horizontal roads
        roads.push({
          name: i === 2 ? "Main Street" : `${i + 1}th Avenue`,
          start: { x: 50, y: 50 + i * 100 },
          end: { x: 550, y: 50 + i * 100 },
          width: i === 2 ? 14 : 10,
        })

        // Vertical roads
        roads.push({
          name: i === 2 ? "Central Boulevard" : `${i + 1}th Street`,
          start: { x: 50 + i * 100, y: 50 },
          end: { x: 50 + i * 100, y: 450 },
          width: i === 2 ? 14 : 10,
        })

        // Add signals at intersections
        for (let j = 0; j < 5; j++) {
          signals.push({
            x: 50 + i * 100,
            y: 50 + j * 100,
            status: Math.random() > 0.7 ? "yellow" : Math.random() > 0.5 ? "green" : "red",
            efficiency: randomNumber(70, 98),
          })
        }
      }

      // Add charging stations for metro city
      chargingStations.push(
        {
          x: 150,
          y: 150,
          status: "available",
          name: "Downtown Charger",
          capacity: 4,
          available: 3,
          chargingSpeed: "Fast",
        },
        {
          x: 350,
          y: 250,
          status: "busy",
          name: "Central Station",
          capacity: 6,
          available: 1,
          chargingSpeed: "Ultra Fast",
        },
        {
          x: 450,
          y: 150,
          status: "available",
          name: "North Charger",
          capacity: 2,
          available: 2,
          chargingSpeed: "Standard",
        },
        {
          x: 150,
          y: 350,
          status: "maintenance",
          name: "West Charger",
          capacity: 4,
          available: 0,
          chargingSpeed: "Fast",
        },
      )
      break

    case "downtown":
      // Dense grid for downtown
      for (let i = 0; i < 7; i++) {
        // Horizontal roads
        roads.push({
          name:
            i === 3 ? "Downtown Boulevard" : `${["Oak", "Elm", "Pine", "Maple", "Cedar", "Birch", "Walnut"][i]} Street`,
          start: { x: 50, y: 50 + i * 60 },
          end: { x: 470, y: 50 + i * 60 },
          width: i === 3 ? 14 : 8,
        })

        // Vertical roads
        roads.push({
          name: i === 3 ? "Main Street" : `${i + 1}th Avenue`,
          start: { x: 50 + i * 60, y: 50 },
          end: { x: 50 + i * 60, y: 410 },
          width: i === 3 ? 14 : 8,
        })

        // Add signals at intersections
        for (let j = 0; j < 7; j++) {
          signals.push({
            x: 50 + i * 60,
            y: 50 + j * 60,
            status: Math.random() > 0.6 ? "yellow" : Math.random() > 0.4 ? "green" : "red",
            efficiency: randomNumber(65, 95),
          })
        }
      }

      // Add charging stations for downtown
      chargingStations.push(
        {
          x: 110,
          y: 110,
          status: "available",
          name: "City Hall Charger",
          capacity: 8,
          available: 5,
          chargingSpeed: "Fast",
        },
        {
          x: 290,
          y: 230,
          status: "busy",
          name: "Shopping District",
          capacity: 10,
          available: 2,
          chargingSpeed: "Ultra Fast",
        },
        {
          x: 410,
          y: 170,
          status: "available",
          name: "Financial District",
          capacity: 6,
          available: 4,
          chargingSpeed: "Fast",
        },
        {
          x: 230,
          y: 350,
          status: "busy",
          name: "Theater District",
          capacity: 4,
          available: 1,
          chargingSpeed: "Standard",
        },
        {
          x: 170,
          y: 290,
          status: "maintenance",
          name: "Central Park",
          capacity: 12,
          available: 0,
          chargingSpeed: "Fast",
        },
      )
      break

    case "suburban":
      // Curved roads for suburban area
      roads.push({
        name: "Suburban Drive",
        start: { x: 50, y: 250 },
        end: { x: 550, y: 250 },
        width: 12,
      })

      roads.push({
        name: "Maple Avenue",
        start: { x: 300, y: 50 },
        end: { x: 300, y: 450 },
        width: 12,
      })

      // Add some curved neighborhood roads
      roads.push({
        name: "Oak Lane",
        start: { x: 100, y: 100 },
        end: { x: 200, y: 200 },
        width: 8,
      })

      roads.push({
        name: "Pine Court",
        start: { x: 400, y: 100 },
        end: { x: 500, y: 200 },
        width: 8,
      })

      roads.push({
        name: "Cedar Way",
        start: { x: 100, y: 400 },
        end: { x: 200, y: 300 },
        width: 8,
      })

      roads.push({
        name: "Birch Road",
        start: { x: 400, y: 400 },
        end: { x: 500, y: 300 },
        width: 8,
      })

      // Add signals at major intersections
      signals.push({
        x: 300,
        y: 250,
        status: "green",
        efficiency: randomNumber(85, 98),
      })

      signals.push({
        x: 200,
        y: 200,
        status: "yellow",
        efficiency: randomNumber(75, 90),
      })

      signals.push({
        x: 400,
        y: 200,
        status: "red",
        efficiency: randomNumber(70, 85),
      })

      signals.push({
        x: 200,
        y: 300,
        status: "green",
        efficiency: randomNumber(80, 95),
      })

      signals.push({
        x: 400,
        y: 300,
        status: "yellow",
        efficiency: randomNumber(75, 90),
      })

      // Add charging stations for suburban area
      chargingStations.push(
        {
          x: 300,
          y: 250,
          status: "available",
          name: "Community Center",
          capacity: 4,
          available: 3,
          chargingSpeed: "Standard",
        },
        {
          x: 200,
          y: 200,
          status: "available",
          name: "Oak Lane Plaza",
          capacity: 2,
          available: 2,
          chargingSpeed: "Standard",
        },
        {
          x: 450,
          y: 250,
          status: "busy",
          name: "Suburban Mall",
          capacity: 8,
          available: 2,
          chargingSpeed: "Fast",
        },
      )
      break

    case "industrial":
      // Grid with large blocks for industrial zone
      for (let i = 0; i < 3; i++) {
        // Horizontal roads
        roads.push({
          name: i === 1 ? "Industrial Parkway" : `Warehouse ${i + 1} Road`,
          start: { x: 50, y: 100 + i * 150 },
          end: { x: 550, y: 100 + i * 150 },
          width: i === 1 ? 16 : 12,
        })

        // Vertical roads
        roads.push({
          name: i === 1 ? "Factory Boulevard" : `Distribution ${i + 1} Avenue`,
          start: { x: 100 + i * 150, y: 50 },
          end: { x: 100 + i * 150, y: 450 },
          width: i === 1 ? 16 : 12,
        })

        // Add signals at intersections
        for (let j = 0; j < 3; j++) {
          signals.push({
            x: 100 + i * 150,
            y: 100 + j * 150,
            status: Math.random() > 0.6 ? "green" : Math.random() > 0.3 ? "yellow" : "red",
            efficiency: randomNumber(75, 95),
          })
        }
      }

      // Add charging stations for industrial zone
      chargingStations.push(
        {
          x: 100,
          y: 100,
          status: "available",
          name: "Factory 1 Charger",
          capacity: 10,
          available: 8,
          chargingSpeed: "Fast",
        },
        {
          x: 250,
          y: 250,
          status: "busy",
          name: "Distribution Center",
          capacity: 12,
          available: 3,
          chargingSpeed: "Ultra Fast",
        },
        {
          x: 400,
          y: 100,
          status: "available",
          name: "Warehouse Complex",
          capacity: 8,
          available: 6,
          chargingSpeed: "Fast",
        },
        {
          x: 250,
          y: 400,
          status: "maintenance",
          name: "Logistics Hub",
          capacity: 6,
          available: 0,
          chargingSpeed: "Fast",
        },
      )
      break

    default:
      // Default to metro city
      for (let i = 0; i < 5; i++) {
        roads.push({
          name: `Road ${i + 1}`,
          start: { x: 50, y: 50 + i * 100 },
          end: { x: 550, y: 50 + i * 100 },
          width: 10,
        })

        roads.push({
          name: `Avenue ${i + 1}`,
          start: { x: 50 + i * 100, y: 50 },
          end: { x: 50 + i * 100, y: 450 },
          width: 10,
        })

        for (let j = 0; j < 5; j++) {
          signals.push({
            x: 50 + i * 100,
            y: 50 + j * 100,
            status: Math.random() > 0.7 ? "yellow" : Math.random() > 0.5 ? "green" : "red",
            efficiency: randomNumber(70, 98),
          })
        }
      }

      // Add default charging stations
      chargingStations.push(
        {
          x: 150,
          y: 150,
          status: "available",
          name: "Central Charger",
          capacity: 4,
          available: 3,
          chargingSpeed: "Fast",
        },
        {
          x: 350,
          y: 250,
          status: "busy",
          name: "Main Station",
          capacity: 6,
          available: 1,
          chargingSpeed: "Fast",
        },
      )
  }

  // Generate vehicles
  const vehicleTypes = ["ev", "av", "traditional"]
  const vehicleCount = {
    "metro-city": 50,
    downtown: 80,
    suburban: 30,
    industrial: 40,
  }

  const count = vehicleCount[cityType as keyof typeof vehicleCount] || 50

  for (let i = 0; i < count; i++) {
    const type = vehicleTypes[Math.floor(Math.random() * vehicleTypes.length)]

    // Place vehicles on roads
    const onHorizontal = Math.random() > 0.5
    const roadIndex = Math.floor((Math.random() * roads.length) / 2)
    const road = roads[onHorizontal ? roadIndex : roadIndex + roads.length / 2]

    if (!road) continue

    const progress = Math.random()
    const x = onHorizontal ? road.start.x + (road.end.x - road.start.x) * progress : road.start.x
    const y = onHorizontal ? road.start.y : road.start.y + (road.end.y - road.start.y) * progress

    vehicles.push({
      type,
      x,
      y,
      direction: onHorizontal ? 0 : Math.PI / 2,
      speed: type === "ev" ? randomNumber(2, 3) : type === "av" ? randomNumber(1, 2) : randomNumber(1, 3),
    })
  }

  return {
    roads,
    signals,
    vehicles,
    chargingStations, // Include charging stations in the returned data
  }
}

// Generate analytics data
export function generateAnalyticsData(timeRange = "30d") {
  // AI insights
  const aiInsights = {
    insights: [
      {
        type: "improvement",
        title: "Traffic Flow Optimization",
        description:
          "The AI has identified a 24.8% improvement in traffic flow efficiency across all corridors compared to traditional signal timing.",
        impact: "High",
        confidence: 94,
      },
      {
        type: "warning",
        title: "Downtown Corridor Congestion",
        description:
          "Predicted congestion in the Downtown corridor between 4-6 PM due to upcoming event at the convention center.",
        impact: "Medium",
        confidence: 87,
      },
      {
        type: "prediction",
        title: "EV Battery Optimization",
        description:
          "Current signal timing is extending EV battery range by an estimated 15.3% by reducing stops and idle time.",
        impact: "High",
        confidence: 92,
      },
    ],
  }

  // Predictive analytics data
  const predictiveAnalytics = []
  const days = timeRange === "7d" ? 7 : timeRange === "30d" ? 30 : timeRange === "90d" ? 90 : 30

  for (let i = 0; i < days; i++) {
    const date = new Date(2025, 2, 1 + i)
    const dateStr = date.toLocaleDateString("en-US", { month: "short", day: "numeric" })

    const actual = i < days / 2 ? randomNumber(800, 1200) : null
    const predicted = randomNumber(850, 1150)
    const variance = randomNumber(50, 150)

    predictiveAnalytics.push({
      date: dateStr,
      actual: actual,
      predicted: predicted,
      lowerBound: predicted - variance,
      upperBound: predicted + variance,
    })
  }

  // Corridor comparison data
  const corridorComparison = [
    {
      name: "Main Street",
      id: "main-street",
      trafficFlow: randomNumber(800, 1200),
      energySavings: randomNumber(100, 200),
      emissionsReduction: randomNumber(50, 100),
      efficiency: randomNumber(80, 95),
    },
    {
      name: "Downtown",
      id: "downtown",
      trafficFlow: randomNumber(1000, 1500),
      energySavings: randomNumber(80, 180),
      emissionsReduction: randomNumber(40, 90),
      efficiency: randomNumber(70, 85),
    },
    {
      name: "University Ave",
      id: "university",
      trafficFlow: randomNumber(700, 1100),
      energySavings: randomNumber(120, 220),
      emissionsReduction: randomNumber(60, 110),
      efficiency: randomNumber(85, 98),
    },
    {
      name: "Industrial Zone",
      id: "industrial",
      trafficFlow: randomNumber(600, 900),
      energySavings: randomNumber(90, 190),
      emissionsReduction: randomNumber(45, 95),
      efficiency: randomNumber(75, 90),
    },
  ]

  // Emissions reduction data
  const emissionsReduction = []
  for (let i = 0; i < 12; i++) {
    const date = new Date(2025, i, 1)
    const dateStr = date.toLocaleDateString("en-US", { month: "short" })

    const reduction = randomNumber(500, 1000)
    const cumulative = i === 0 ? reduction : emissionsReduction[i - 1]?.cumulative + reduction || reduction

    emissionsReduction.push({
      date: dateStr,
      reduction,
      cumulative,
    })
  }

  // Vehicle type performance data
  const vehicleTypePerformance = [
    {
      type: "Electric Vehicles",
      efficiency: randomNumber(85, 95),
      energySavings: randomNumber(80, 95),
      emissionsReduction: randomNumber(90, 100),
      trafficFlow: randomNumber(75, 90),
      adaptability: randomNumber(70, 85),
    },
    {
      type: "Autonomous Vehicles",
      efficiency: randomNumber(80, 90),
      energySavings: randomNumber(70, 85),
      emissionsReduction: randomNumber(75, 90),
      trafficFlow: randomNumber(85, 95),
      adaptability: randomNumber(90, 100),
    },
    {
      type: "Traditional Vehicles",
      efficiency: randomNumber(60, 75),
      energySavings: randomNumber(50, 65),
      emissionsReduction: randomNumber(40, 60),
      trafficFlow: randomNumber(65, 80),
      adaptability: randomNumber(50, 70),
    },
  ]

  return {
    aiInsights,
    predictiveAnalytics,
    corridorComparison,
    emissionsReduction,
    vehicleTypePerformance,
  }
}

// Update the generate-data.tsx file to include system health data

// Add this function to the existing file
export function generateSystemHealthData() {
  return {
    overallHealth: 98.2,
    components: [
      {
        name: "Traffic Signal Network",
        status: "operational",
        uptime: "99.8%",
        lastIssue: null,
      },
      {
        name: "Main Street Corridor",
        status: "operational",
        uptime: "100%",
        lastIssue: null,
      },
      {
        name: "Downtown Corridor",
        status: "warning",
        uptime: "97.5%",
        lastIssue: "March 15, 2025 - Signal timing issue",
      },
      {
        name: "University Avenue Corridor",
        status: "operational",
        uptime: "99.9%",
        lastIssue: null,
      },
      {
        name: "Industrial Zone Corridor",
        status: "operational",
        uptime: "99.7%",
        lastIssue: null,
      },
      {
        name: "Data Processing System",
        status: "operational",
        uptime: "99.9%",
        lastIssue: null,
      },
      {
        name: "AI Prediction Engine",
        status: "operational",
        uptime: "99.5%",
        lastIssue: "March 10, 2025 - Model calibration",
      },
      {
        name: "Vehicle Detection Sensors",
        status: "warning",
        uptime: "96.8%",
        lastIssue: "March 16, 2025 - Calibration needed",
      },
    ],
    alerts: [
      {
        id: "ALT-001",
        severity: "medium",
        message: "Downtown Corridor signal S-006 showing intermittent timing issues",
        timestamp: "March 16, 2025 - 14:32",
        acknowledged: false,
      },
      {
        id: "ALT-002",
        severity: "low",
        message: "Vehicle detection sensor at University Ave requires calibration",
        timestamp: "March 16, 2025 - 10:15",
        acknowledged: false,
      },
      {
        id: "ALT-003",
        severity: "low",
        message: "Battery backup system test recommended for Main Street signals",
        timestamp: "March 15, 2025 - 09:45",
        acknowledged: true,
      },
      {
        id: "ALT-004",
        severity: "high",
        message: "Network connectivity issue at Industrial Zone resolved",
        timestamp: "March 14, 2025 - 16:20",
        acknowledged: true,
      },
      {
        id: "ALT-005",
        severity: "medium",
        message: "AI model accuracy below threshold for Downtown predictions",
        timestamp: "March 13, 2025 - 11:05",
        acknowledged: true,
      },
    ],
    maintenance: [
      {
        id: "MNT-001",
        component: "Downtown Corridor Signal S-006",
        scheduledFor: "March 18, 2025 - 02:00 AM",
        duration: "2 hours",
        status: "scheduled",
      },
      {
        id: "MNT-002",
        component: "Vehicle Detection Sensors - University Ave",
        scheduledFor: "March 19, 2025 - 10:00 AM",
        duration: "4 hours",
        status: "scheduled",
      },
      {
        id: "MNT-003",
        component: "AI Model Calibration",
        scheduledFor: "March 20, 2025 - 01:00 AM",
        duration: "3 hours",
        status: "scheduled",
      },
      {
        id: "MNT-004",
        component: "System Backup and Update",
        scheduledFor: "March 14, 2025 - 02:00 AM",
        duration: "1 hour",
        status: "completed",
      },
      {
        id: "MNT-005",
        component: "Industrial Zone Network Infrastructure",
        scheduledFor: "March 14, 2025 - 03:00 PM",
        duration: "2 hours",
        status: "completed",
      },
    ],
  }
}

